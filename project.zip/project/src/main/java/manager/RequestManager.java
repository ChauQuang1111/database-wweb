package manager;

import java.util.ArrayList;

import javax.servlet.annotation.WebServlet;

import entiity.Request;


public class RequestManager {
	private ArrayList<Request> reqList ;
	
}
