﻿namespace Vender
{
    partial class SellingForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SellingForm));
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges7 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges8 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties17 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties18 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties19 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties20 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges9 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges10 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges11 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties21 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties22 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties23 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties24 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties25 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties26 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties27 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties28 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties29 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties30 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties31 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties32 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges12 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            this.bunifuFormDock1 = new Bunifu.UI.WinForms.BunifuFormDock();
            this.labelShowSellerName = new System.Windows.Forms.Label();
            this.bunifuShadowPanel1 = new Bunifu.UI.WinForm.BunifuShadowPanel.BunifuShadowPanel();
            this.bunifuGradientPanel7 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.labelDate = new System.Windows.Forms.Label();
            this.ButtonRefresh = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.ButtonClearOrder = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.DropdownPrint = new Bunifu.UI.WinForms.BunifuDropdown();
            this.LabelMessageBill = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.TextBoxBillID = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.bunifuSeparator1 = new Bunifu.Framework.UI.BunifuSeparator();
            this.LabelTodayAmount = new System.Windows.Forms.Label();
            this.labelAmount = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.ButtonAdd = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.ButtonPrint = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.bunifuGradientPanel5 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.DataGridViewSellList = new Bunifu.UI.WinForms.BunifuDataGridView();
            this.bunifuGradientPanel6 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.bunifuLabel5 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuGradientPanel3 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.DataGridViewOrder = new Bunifu.UI.WinForms.BunifuDataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bunifuGradientPanel4 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.bunifuLabel4 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuGradientPanel1 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.LabelMessage = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.ButtonAddOrder = new Bunifu.Framework.UI.BunifuFlatButton();
            this.CategoryDropdown = new Bunifu.UI.WinForms.BunifuDropdown();
            this.DataGridViewProduct = new Bunifu.UI.WinForms.BunifuDataGridView();
            this.bunifuLabel3 = new Bunifu.UI.WinForms.BunifuLabel();
            this.ButtonAddSellers = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.TextBoxQuantity = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.bunifuLabel2 = new Bunifu.UI.WinForms.BunifuLabel();
            this.TextBoxPrice = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.bunifuLabel1 = new Bunifu.UI.WinForms.BunifuLabel();
            this.TextBoxName = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.bunifuGradientPanel2 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.bunifuLabel6 = new Bunifu.UI.WinForms.BunifuLabel();
            this.LogoutButton = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.bunifuImageButton2 = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuImageButton1 = new Bunifu.UI.WinForms.BunifuImageButton();
            this.bunifuShadowPanel1.SuspendLayout();
            this.bunifuGradientPanel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.bunifuGradientPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridViewSellList)).BeginInit();
            this.bunifuGradientPanel6.SuspendLayout();
            this.bunifuGradientPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridViewOrder)).BeginInit();
            this.bunifuGradientPanel4.SuspendLayout();
            this.bunifuGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridViewProduct)).BeginInit();
            this.bunifuGradientPanel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton2)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuFormDock1
            // 
            this.bunifuFormDock1.AllowFormDragging = true;
            this.bunifuFormDock1.AllowFormDropShadow = true;
            this.bunifuFormDock1.AllowFormResizing = true;
            this.bunifuFormDock1.AllowHidingBottomRegion = true;
            this.bunifuFormDock1.AllowOpacityChangesWhileDragging = false;
            this.bunifuFormDock1.BorderOptions.BottomBorder.BorderColor = System.Drawing.Color.Silver;
            this.bunifuFormDock1.BorderOptions.BottomBorder.BorderThickness = 1;
            this.bunifuFormDock1.BorderOptions.BottomBorder.ShowBorder = true;
            this.bunifuFormDock1.BorderOptions.LeftBorder.BorderColor = System.Drawing.Color.Silver;
            this.bunifuFormDock1.BorderOptions.LeftBorder.BorderThickness = 1;
            this.bunifuFormDock1.BorderOptions.LeftBorder.ShowBorder = true;
            this.bunifuFormDock1.BorderOptions.RightBorder.BorderColor = System.Drawing.Color.Silver;
            this.bunifuFormDock1.BorderOptions.RightBorder.BorderThickness = 1;
            this.bunifuFormDock1.BorderOptions.RightBorder.ShowBorder = true;
            this.bunifuFormDock1.BorderOptions.TopBorder.BorderColor = System.Drawing.Color.Silver;
            this.bunifuFormDock1.BorderOptions.TopBorder.BorderThickness = 1;
            this.bunifuFormDock1.BorderOptions.TopBorder.ShowBorder = true;
            this.bunifuFormDock1.ContainerControl = this;
            this.bunifuFormDock1.DockingIndicatorsColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(215)))), ((int)(((byte)(233)))));
            this.bunifuFormDock1.DockingIndicatorsOpacity = 0.5D;
            this.bunifuFormDock1.DockingOptions.DockAll = true;
            this.bunifuFormDock1.DockingOptions.DockBottomLeft = true;
            this.bunifuFormDock1.DockingOptions.DockBottomRight = true;
            this.bunifuFormDock1.DockingOptions.DockFullScreen = true;
            this.bunifuFormDock1.DockingOptions.DockLeft = true;
            this.bunifuFormDock1.DockingOptions.DockRight = true;
            this.bunifuFormDock1.DockingOptions.DockTopLeft = true;
            this.bunifuFormDock1.DockingOptions.DockTopRight = true;
            this.bunifuFormDock1.FormDraggingOpacity = 0.9D;
            this.bunifuFormDock1.ParentForm = this;
            this.bunifuFormDock1.ShowCursorChanges = true;
            this.bunifuFormDock1.ShowDockingIndicators = true;
            this.bunifuFormDock1.TitleBarOptions.AllowFormDragging = true;
            this.bunifuFormDock1.TitleBarOptions.BunifuFormDock = this.bunifuFormDock1;
            this.bunifuFormDock1.TitleBarOptions.DoubleClickToExpandWindow = true;
            this.bunifuFormDock1.TitleBarOptions.TitleBarControl = null;
            this.bunifuFormDock1.TitleBarOptions.UseBackColorOnDockingIndicators = false;
            // 
            // labelShowSellerName
            // 
            this.labelShowSellerName.AutoSize = true;
            this.labelShowSellerName.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelShowSellerName.Location = new System.Drawing.Point(97, 27);
            this.labelShowSellerName.Name = "labelShowSellerName";
            this.labelShowSellerName.Size = new System.Drawing.Size(137, 30);
            this.labelShowSellerName.TabIndex = 0;
            this.labelShowSellerName.Text = "Seller Name ";
            // 
            // bunifuShadowPanel1
            // 
            this.bunifuShadowPanel1.BackColor = System.Drawing.Color.White;
            this.bunifuShadowPanel1.BorderColor = System.Drawing.Color.White;
            this.bunifuShadowPanel1.Controls.Add(this.bunifuGradientPanel7);
            this.bunifuShadowPanel1.Controls.Add(this.ButtonRefresh);
            this.bunifuShadowPanel1.Controls.Add(this.ButtonClearOrder);
            this.bunifuShadowPanel1.Controls.Add(this.DropdownPrint);
            this.bunifuShadowPanel1.Controls.Add(this.LabelMessageBill);
            this.bunifuShadowPanel1.Controls.Add(this.pictureBox1);
            this.bunifuShadowPanel1.Controls.Add(this.TextBoxBillID);
            this.bunifuShadowPanel1.Controls.Add(this.bunifuSeparator1);
            this.bunifuShadowPanel1.Controls.Add(this.LabelTodayAmount);
            this.bunifuShadowPanel1.Controls.Add(this.labelAmount);
            this.bunifuShadowPanel1.Controls.Add(this.label1);
            this.bunifuShadowPanel1.Controls.Add(this.label2);
            this.bunifuShadowPanel1.Controls.Add(this.ButtonAdd);
            this.bunifuShadowPanel1.Controls.Add(this.ButtonPrint);
            this.bunifuShadowPanel1.Controls.Add(this.bunifuGradientPanel5);
            this.bunifuShadowPanel1.Controls.Add(this.bunifuGradientPanel3);
            this.bunifuShadowPanel1.Controls.Add(this.bunifuGradientPanel1);
            this.bunifuShadowPanel1.Location = new System.Drawing.Point(-2, 96);
            this.bunifuShadowPanel1.Name = "bunifuShadowPanel1";
            this.bunifuShadowPanel1.PanelColor = System.Drawing.Color.Empty;
            this.bunifuShadowPanel1.ShadowDept = 2;
            this.bunifuShadowPanel1.ShadowTopLeftVisible = false;
            this.bunifuShadowPanel1.Size = new System.Drawing.Size(1345, 736);
            this.bunifuShadowPanel1.TabIndex = 3;
            // 
            // bunifuGradientPanel7
            // 
            this.bunifuGradientPanel7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel7.BackgroundImage")));
            this.bunifuGradientPanel7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel7.Controls.Add(this.labelDate);
            this.bunifuGradientPanel7.GradientBottomLeft = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(189)))), ((int)(((byte)(241)))));
            this.bunifuGradientPanel7.GradientBottomRight = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(191)))));
            this.bunifuGradientPanel7.GradientTopLeft = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(189)))), ((int)(((byte)(241)))));
            this.bunifuGradientPanel7.GradientTopRight = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(191)))));
            this.bunifuGradientPanel7.Location = new System.Drawing.Point(1043, 482);
            this.bunifuGradientPanel7.Name = "bunifuGradientPanel7";
            this.bunifuGradientPanel7.Quality = 10;
            this.bunifuGradientPanel7.Size = new System.Drawing.Size(283, 50);
            this.bunifuGradientPanel7.TabIndex = 40;
            // 
            // labelDate
            // 
            this.labelDate.AutoSize = true;
            this.labelDate.BackColor = System.Drawing.Color.Transparent;
            this.labelDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDate.ForeColor = System.Drawing.Color.White;
            this.labelDate.Location = new System.Drawing.Point(26, 14);
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(61, 25);
            this.labelDate.TabIndex = 7;
            this.labelDate.Text = "Date";
            // 
            // ButtonRefresh
            // 
            this.ButtonRefresh.AllowToggling = false;
            this.ButtonRefresh.AnimationSpeed = 200;
            this.ButtonRefresh.AutoGenerateColors = false;
            this.ButtonRefresh.BackColor = System.Drawing.Color.Transparent;
            this.ButtonRefresh.BackColor1 = System.Drawing.Color.WhiteSmoke;
            this.ButtonRefresh.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ButtonRefresh.BackgroundImage")));
            this.ButtonRefresh.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ButtonRefresh.ButtonText = "Refresh";
            this.ButtonRefresh.ButtonTextMarginLeft = 0;
            this.ButtonRefresh.ColorContrastOnClick = 45;
            this.ButtonRefresh.ColorContrastOnHover = 45;
            this.ButtonRefresh.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges7.BottomLeft = true;
            borderEdges7.BottomRight = true;
            borderEdges7.TopLeft = true;
            borderEdges7.TopRight = true;
            this.ButtonRefresh.CustomizableEdges = borderEdges7;
            this.ButtonRefresh.DialogResult = System.Windows.Forms.DialogResult.None;
            this.ButtonRefresh.DisabledBorderColor = System.Drawing.Color.Empty;
            this.ButtonRefresh.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.ButtonRefresh.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.ButtonRefresh.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.ButtonRefresh.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonRefresh.ForeColor = System.Drawing.Color.DimGray;
            this.ButtonRefresh.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.ButtonRefresh.IconMarginLeft = 20;
            this.ButtonRefresh.IconPadding = 16;
            this.ButtonRefresh.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.ButtonRefresh.IdleBorderColor = System.Drawing.Color.WhiteSmoke;
            this.ButtonRefresh.IdleBorderRadius = 1;
            this.ButtonRefresh.IdleBorderThickness = 1;
            this.ButtonRefresh.IdleFillColor = System.Drawing.Color.WhiteSmoke;
            this.ButtonRefresh.IdleIconLeftImage = global::Vender.Properties.Resources.update_left_rotation_1080px;
            this.ButtonRefresh.IdleIconRightImage = null;
            this.ButtonRefresh.IndicateFocus = true;
            this.ButtonRefresh.Location = new System.Drawing.Point(1194, 614);
            this.ButtonRefresh.Name = "ButtonRefresh";
            this.ButtonRefresh.onHoverState.BorderColor = System.Drawing.Color.White;
            this.ButtonRefresh.onHoverState.BorderRadius = 1;
            this.ButtonRefresh.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ButtonRefresh.onHoverState.BorderThickness = 1;
            this.ButtonRefresh.onHoverState.FillColor = System.Drawing.Color.White;
            this.ButtonRefresh.onHoverState.ForeColor = System.Drawing.Color.DodgerBlue;
            this.ButtonRefresh.onHoverState.IconLeftImage = global::Vender.Properties.Resources.update_left_rotation_1080px;
            this.ButtonRefresh.onHoverState.IconRightImage = null;
            this.ButtonRefresh.OnIdleState.BorderColor = System.Drawing.Color.WhiteSmoke;
            this.ButtonRefresh.OnIdleState.BorderRadius = 1;
            this.ButtonRefresh.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ButtonRefresh.OnIdleState.BorderThickness = 1;
            this.ButtonRefresh.OnIdleState.FillColor = System.Drawing.Color.WhiteSmoke;
            this.ButtonRefresh.OnIdleState.ForeColor = System.Drawing.Color.DimGray;
            this.ButtonRefresh.OnIdleState.IconLeftImage = global::Vender.Properties.Resources.update_left_rotation_1080px;
            this.ButtonRefresh.OnIdleState.IconRightImage = null;
            this.ButtonRefresh.OnPressedState.BorderColor = System.Drawing.Color.WhiteSmoke;
            this.ButtonRefresh.OnPressedState.BorderRadius = 1;
            this.ButtonRefresh.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ButtonRefresh.OnPressedState.BorderThickness = 1;
            this.ButtonRefresh.OnPressedState.FillColor = System.Drawing.Color.WhiteSmoke;
            this.ButtonRefresh.OnPressedState.ForeColor = System.Drawing.Color.DimGray;
            this.ButtonRefresh.OnPressedState.IconLeftImage = null;
            this.ButtonRefresh.OnPressedState.IconRightImage = null;
            this.ButtonRefresh.Size = new System.Drawing.Size(132, 48);
            this.ButtonRefresh.TabIndex = 39;
            this.ButtonRefresh.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ButtonRefresh.TextMarginLeft = 0;
            this.ButtonRefresh.UseDefaultRadiusAndThickness = true;
            this.ButtonRefresh.Click += new System.EventHandler(this.ButtonRefresh_Click);
            // 
            // ButtonClearOrder
            // 
            this.ButtonClearOrder.AllowToggling = false;
            this.ButtonClearOrder.AnimationSpeed = 200;
            this.ButtonClearOrder.AutoGenerateColors = false;
            this.ButtonClearOrder.BackColor = System.Drawing.Color.Transparent;
            this.ButtonClearOrder.BackColor1 = System.Drawing.Color.White;
            this.ButtonClearOrder.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ButtonClearOrder.BackgroundImage")));
            this.ButtonClearOrder.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ButtonClearOrder.ButtonText = "Clear Order";
            this.ButtonClearOrder.ButtonTextMarginLeft = 0;
            this.ButtonClearOrder.ColorContrastOnClick = 45;
            this.ButtonClearOrder.ColorContrastOnHover = 45;
            this.ButtonClearOrder.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges8.BottomLeft = true;
            borderEdges8.BottomRight = true;
            borderEdges8.TopLeft = true;
            borderEdges8.TopRight = true;
            this.ButtonClearOrder.CustomizableEdges = borderEdges8;
            this.ButtonClearOrder.DialogResult = System.Windows.Forms.DialogResult.None;
            this.ButtonClearOrder.DisabledBorderColor = System.Drawing.Color.Empty;
            this.ButtonClearOrder.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.ButtonClearOrder.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.ButtonClearOrder.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.ButtonClearOrder.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonClearOrder.ForeColor = System.Drawing.Color.DimGray;
            this.ButtonClearOrder.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.ButtonClearOrder.IconMarginLeft = 20;
            this.ButtonClearOrder.IconPadding = 16;
            this.ButtonClearOrder.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.ButtonClearOrder.IdleBorderColor = System.Drawing.Color.White;
            this.ButtonClearOrder.IdleBorderRadius = 1;
            this.ButtonClearOrder.IdleBorderThickness = 1;
            this.ButtonClearOrder.IdleFillColor = System.Drawing.Color.White;
            this.ButtonClearOrder.IdleIconLeftImage = global::Vender.Properties.Resources.Delete_1080px;
            this.ButtonClearOrder.IdleIconRightImage = null;
            this.ButtonClearOrder.IndicateFocus = true;
            this.ButtonClearOrder.Location = new System.Drawing.Point(864, 425);
            this.ButtonClearOrder.Name = "ButtonClearOrder";
            this.ButtonClearOrder.onHoverState.BorderColor = System.Drawing.Color.White;
            this.ButtonClearOrder.onHoverState.BorderRadius = 1;
            this.ButtonClearOrder.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ButtonClearOrder.onHoverState.BorderThickness = 1;
            this.ButtonClearOrder.onHoverState.FillColor = System.Drawing.Color.White;
            this.ButtonClearOrder.onHoverState.ForeColor = System.Drawing.Color.DodgerBlue;
            this.ButtonClearOrder.onHoverState.IconLeftImage = global::Vender.Properties.Resources.Delete_1080px;
            this.ButtonClearOrder.onHoverState.IconRightImage = null;
            this.ButtonClearOrder.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.ButtonClearOrder.OnIdleState.BorderRadius = 1;
            this.ButtonClearOrder.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ButtonClearOrder.OnIdleState.BorderThickness = 1;
            this.ButtonClearOrder.OnIdleState.FillColor = System.Drawing.Color.White;
            this.ButtonClearOrder.OnIdleState.ForeColor = System.Drawing.Color.DimGray;
            this.ButtonClearOrder.OnIdleState.IconLeftImage = global::Vender.Properties.Resources.Delete_1080px;
            this.ButtonClearOrder.OnIdleState.IconRightImage = null;
            this.ButtonClearOrder.OnPressedState.BorderColor = System.Drawing.Color.White;
            this.ButtonClearOrder.OnPressedState.BorderRadius = 1;
            this.ButtonClearOrder.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ButtonClearOrder.OnPressedState.BorderThickness = 1;
            this.ButtonClearOrder.OnPressedState.FillColor = System.Drawing.Color.White;
            this.ButtonClearOrder.OnPressedState.ForeColor = System.Drawing.Color.DimGray;
            this.ButtonClearOrder.OnPressedState.IconLeftImage = null;
            this.ButtonClearOrder.OnPressedState.IconRightImage = null;
            this.ButtonClearOrder.Size = new System.Drawing.Size(158, 48);
            this.ButtonClearOrder.TabIndex = 37;
            this.ButtonClearOrder.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ButtonClearOrder.TextMarginLeft = 0;
            this.ButtonClearOrder.UseDefaultRadiusAndThickness = true;
            this.ButtonClearOrder.Click += new System.EventHandler(this.ButtonClearOrder_Click);
            // 
            // DropdownPrint
            // 
            this.DropdownPrint.BackColor = System.Drawing.Color.White;
            this.DropdownPrint.BorderRadius = 1;
            this.DropdownPrint.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            this.DropdownPrint.Direction = Bunifu.UI.WinForms.BunifuDropdown.Directions.Down;
            this.DropdownPrint.DisabledColor = System.Drawing.Color.WhiteSmoke;
            this.DropdownPrint.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.DropdownPrint.DropdownBorderThickness = Bunifu.UI.WinForms.BunifuDropdown.BorderThickness.Thick;
            this.DropdownPrint.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.DropdownPrint.DropDownTextAlign = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left;
            this.DropdownPrint.FillDropDown = false;
            this.DropdownPrint.FillIndicator = false;
            this.DropdownPrint.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DropdownPrint.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            this.DropdownPrint.FormattingEnabled = true;
            this.DropdownPrint.Icon = null;
            this.DropdownPrint.IndicatorColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            this.DropdownPrint.IndicatorLocation = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right;
            this.DropdownPrint.ItemBackColor = System.Drawing.Color.WhiteSmoke;
            this.DropdownPrint.ItemBorderColor = System.Drawing.Color.WhiteSmoke;
            this.DropdownPrint.ItemForeColor = System.Drawing.Color.Black;
            this.DropdownPrint.ItemHeight = 26;
            this.DropdownPrint.ItemHighLightColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            this.DropdownPrint.Items.AddRange(new object[] {
            "Order",
            "Sells List"});
            this.DropdownPrint.Location = new System.Drawing.Point(1043, 682);
            this.DropdownPrint.Name = "DropdownPrint";
            this.DropdownPrint.Size = new System.Drawing.Size(142, 32);
            this.DropdownPrint.TabIndex = 36;
            this.DropdownPrint.Text = "Iteam to print";
            // 
            // LabelMessageBill
            // 
            this.LabelMessageBill.AutoSize = true;
            this.LabelMessageBill.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelMessageBill.ForeColor = System.Drawing.Color.Red;
            this.LabelMessageBill.Location = new System.Drawing.Point(1056, 453);
            this.LabelMessageBill.Name = "LabelMessageBill";
            this.LabelMessageBill.Size = new System.Drawing.Size(0, 21);
            this.LabelMessageBill.TabIndex = 35;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1049, 160);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(272, 260);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // TextBoxBillID
            // 
            this.TextBoxBillID.AcceptsReturn = false;
            this.TextBoxBillID.AcceptsTab = false;
            this.TextBoxBillID.AnimationSpeed = 200;
            this.TextBoxBillID.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.TextBoxBillID.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.TextBoxBillID.BackColor = System.Drawing.Color.White;
            this.TextBoxBillID.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("TextBoxBillID.BackgroundImage")));
            this.TextBoxBillID.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            this.TextBoxBillID.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            this.TextBoxBillID.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            this.TextBoxBillID.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            this.TextBoxBillID.BorderRadius = 1;
            this.TextBoxBillID.BorderThickness = 1;
            this.TextBoxBillID.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.TextBoxBillID.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxBillID.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.TextBoxBillID.DefaultText = "";
            this.TextBoxBillID.FillColor = System.Drawing.Color.White;
            this.TextBoxBillID.ForeColor = System.Drawing.Color.DimGray;
            this.TextBoxBillID.HideSelection = true;
            this.TextBoxBillID.IconLeft = null;
            this.TextBoxBillID.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxBillID.IconPadding = 10;
            this.TextBoxBillID.IconRight = null;
            this.TextBoxBillID.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxBillID.Lines = new string[0];
            this.TextBoxBillID.Location = new System.Drawing.Point(1047, 558);
            this.TextBoxBillID.MaxLength = 32767;
            this.TextBoxBillID.MinimumSize = new System.Drawing.Size(1, 1);
            this.TextBoxBillID.Modified = false;
            this.TextBoxBillID.Multiline = false;
            this.TextBoxBillID.Name = "TextBoxBillID";
            stateProperties17.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            stateProperties17.FillColor = System.Drawing.Color.Empty;
            stateProperties17.ForeColor = System.Drawing.Color.Empty;
            stateProperties17.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.TextBoxBillID.OnActiveState = stateProperties17;
            stateProperties18.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            stateProperties18.FillColor = System.Drawing.Color.White;
            stateProperties18.ForeColor = System.Drawing.Color.Empty;
            stateProperties18.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.TextBoxBillID.OnDisabledState = stateProperties18;
            stateProperties19.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            stateProperties19.FillColor = System.Drawing.Color.Empty;
            stateProperties19.ForeColor = System.Drawing.Color.Empty;
            stateProperties19.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.TextBoxBillID.OnHoverState = stateProperties19;
            stateProperties20.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            stateProperties20.FillColor = System.Drawing.Color.White;
            stateProperties20.ForeColor = System.Drawing.Color.DimGray;
            stateProperties20.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.TextBoxBillID.OnIdleState = stateProperties20;
            this.TextBoxBillID.PasswordChar = '\0';
            this.TextBoxBillID.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.TextBoxBillID.PlaceholderText = "Bill ID";
            this.TextBoxBillID.ReadOnly = false;
            this.TextBoxBillID.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.TextBoxBillID.SelectedText = "";
            this.TextBoxBillID.SelectionLength = 0;
            this.TextBoxBillID.SelectionStart = 0;
            this.TextBoxBillID.ShortcutsEnabled = true;
            this.TextBoxBillID.Size = new System.Drawing.Size(141, 48);
            this.TextBoxBillID.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Material;
            this.TextBoxBillID.TabIndex = 28;
            this.TextBoxBillID.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.TextBoxBillID.TextMarginBottom = 0;
            this.TextBoxBillID.TextMarginLeft = 5;
            this.TextBoxBillID.TextMarginTop = 0;
            this.TextBoxBillID.TextPlaceholder = "Bill ID";
            this.TextBoxBillID.UseSystemPasswordChar = false;
            this.TextBoxBillID.WordWrap = true;
            this.TextBoxBillID.Click += new System.EventHandler(this.TextBoxBill_Click);
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator1.LineThickness = 1;
            this.bunifuSeparator1.Location = new System.Drawing.Point(1047, 40);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Size = new System.Drawing.Size(279, 35);
            this.bunifuSeparator1.TabIndex = 8;
            this.bunifuSeparator1.Transparency = 255;
            this.bunifuSeparator1.Vertical = false;
            // 
            // LabelTodayAmount
            // 
            this.LabelTodayAmount.AutoSize = true;
            this.LabelTodayAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelTodayAmount.Location = new System.Drawing.Point(1200, 11);
            this.LabelTodayAmount.Name = "LabelTodayAmount";
            this.LabelTodayAmount.Size = new System.Drawing.Size(25, 25);
            this.LabelTodayAmount.TabIndex = 7;
            this.LabelTodayAmount.Text = "$";
            // 
            // labelAmount
            // 
            this.labelAmount.AutoSize = true;
            this.labelAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAmount.Location = new System.Drawing.Point(1152, 78);
            this.labelAmount.Name = "labelAmount";
            this.labelAmount.Size = new System.Drawing.Size(25, 25);
            this.labelAmount.TabIndex = 7;
            this.labelAmount.Text = "$";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(1049, 78);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 25);
            this.label1.TabIndex = 7;
            this.label1.Text = "Amount :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(1048, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(150, 25);
            this.label2.TabIndex = 7;
            this.label2.Text = "Transaction :";
            // 
            // ButtonAdd
            // 
            this.ButtonAdd.AllowToggling = false;
            this.ButtonAdd.AnimationSpeed = 200;
            this.ButtonAdd.AutoGenerateColors = false;
            this.ButtonAdd.BackColor = System.Drawing.Color.Transparent;
            this.ButtonAdd.BackColor1 = System.Drawing.Color.WhiteSmoke;
            this.ButtonAdd.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ButtonAdd.BackgroundImage")));
            this.ButtonAdd.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ButtonAdd.ButtonText = "Add";
            this.ButtonAdd.ButtonTextMarginLeft = 0;
            this.ButtonAdd.ColorContrastOnClick = 45;
            this.ButtonAdd.ColorContrastOnHover = 45;
            this.ButtonAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges9.BottomLeft = true;
            borderEdges9.BottomRight = true;
            borderEdges9.TopLeft = true;
            borderEdges9.TopRight = true;
            this.ButtonAdd.CustomizableEdges = borderEdges9;
            this.ButtonAdd.DialogResult = System.Windows.Forms.DialogResult.None;
            this.ButtonAdd.DisabledBorderColor = System.Drawing.Color.Empty;
            this.ButtonAdd.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.ButtonAdd.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.ButtonAdd.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.ButtonAdd.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonAdd.ForeColor = System.Drawing.Color.DimGray;
            this.ButtonAdd.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.ButtonAdd.IconMarginLeft = 20;
            this.ButtonAdd.IconPadding = 16;
            this.ButtonAdd.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.ButtonAdd.IdleBorderColor = System.Drawing.Color.WhiteSmoke;
            this.ButtonAdd.IdleBorderRadius = 1;
            this.ButtonAdd.IdleBorderThickness = 1;
            this.ButtonAdd.IdleFillColor = System.Drawing.Color.WhiteSmoke;
            this.ButtonAdd.IdleIconLeftImage = global::Vender.Properties.Resources.create_order_1080px;
            this.ButtonAdd.IdleIconRightImage = null;
            this.ButtonAdd.IndicateFocus = true;
            this.ButtonAdd.Location = new System.Drawing.Point(1194, 558);
            this.ButtonAdd.Name = "ButtonAdd";
            this.ButtonAdd.onHoverState.BorderColor = System.Drawing.Color.White;
            this.ButtonAdd.onHoverState.BorderRadius = 1;
            this.ButtonAdd.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ButtonAdd.onHoverState.BorderThickness = 1;
            this.ButtonAdd.onHoverState.FillColor = System.Drawing.Color.White;
            this.ButtonAdd.onHoverState.ForeColor = System.Drawing.Color.DodgerBlue;
            this.ButtonAdd.onHoverState.IconLeftImage = global::Vender.Properties.Resources.create_order_1080px;
            this.ButtonAdd.onHoverState.IconRightImage = null;
            this.ButtonAdd.OnIdleState.BorderColor = System.Drawing.Color.WhiteSmoke;
            this.ButtonAdd.OnIdleState.BorderRadius = 1;
            this.ButtonAdd.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ButtonAdd.OnIdleState.BorderThickness = 1;
            this.ButtonAdd.OnIdleState.FillColor = System.Drawing.Color.WhiteSmoke;
            this.ButtonAdd.OnIdleState.ForeColor = System.Drawing.Color.DimGray;
            this.ButtonAdd.OnIdleState.IconLeftImage = global::Vender.Properties.Resources.create_order_1080px;
            this.ButtonAdd.OnIdleState.IconRightImage = null;
            this.ButtonAdd.OnPressedState.BorderColor = System.Drawing.Color.WhiteSmoke;
            this.ButtonAdd.OnPressedState.BorderRadius = 1;
            this.ButtonAdd.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ButtonAdd.OnPressedState.BorderThickness = 1;
            this.ButtonAdd.OnPressedState.FillColor = System.Drawing.Color.WhiteSmoke;
            this.ButtonAdd.OnPressedState.ForeColor = System.Drawing.Color.DimGray;
            this.ButtonAdd.OnPressedState.IconLeftImage = null;
            this.ButtonAdd.OnPressedState.IconRightImage = null;
            this.ButtonAdd.Size = new System.Drawing.Size(132, 48);
            this.ButtonAdd.TabIndex = 6;
            this.ButtonAdd.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ButtonAdd.TextMarginLeft = 0;
            this.ButtonAdd.UseDefaultRadiusAndThickness = true;
            this.ButtonAdd.Click += new System.EventHandler(this.ButtonAdd_Click);
            // 
            // ButtonPrint
            // 
            this.ButtonPrint.AllowToggling = false;
            this.ButtonPrint.AnimationSpeed = 200;
            this.ButtonPrint.AutoGenerateColors = false;
            this.ButtonPrint.BackColor = System.Drawing.Color.Transparent;
            this.ButtonPrint.BackColor1 = System.Drawing.Color.WhiteSmoke;
            this.ButtonPrint.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ButtonPrint.BackgroundImage")));
            this.ButtonPrint.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ButtonPrint.ButtonText = "Print";
            this.ButtonPrint.ButtonTextMarginLeft = 0;
            this.ButtonPrint.ColorContrastOnClick = 45;
            this.ButtonPrint.ColorContrastOnHover = 45;
            this.ButtonPrint.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges10.BottomLeft = true;
            borderEdges10.BottomRight = true;
            borderEdges10.TopLeft = true;
            borderEdges10.TopRight = true;
            this.ButtonPrint.CustomizableEdges = borderEdges10;
            this.ButtonPrint.DialogResult = System.Windows.Forms.DialogResult.None;
            this.ButtonPrint.DisabledBorderColor = System.Drawing.Color.Empty;
            this.ButtonPrint.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.ButtonPrint.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.ButtonPrint.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.ButtonPrint.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonPrint.ForeColor = System.Drawing.Color.DimGray;
            this.ButtonPrint.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.ButtonPrint.IconMarginLeft = 20;
            this.ButtonPrint.IconPadding = 16;
            this.ButtonPrint.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.ButtonPrint.IdleBorderColor = System.Drawing.Color.WhiteSmoke;
            this.ButtonPrint.IdleBorderRadius = 1;
            this.ButtonPrint.IdleBorderThickness = 1;
            this.ButtonPrint.IdleFillColor = System.Drawing.Color.WhiteSmoke;
            this.ButtonPrint.IdleIconLeftImage = global::Vender.Properties.Resources.print_1080px;
            this.ButtonPrint.IdleIconRightImage = null;
            this.ButtonPrint.IndicateFocus = true;
            this.ButtonPrint.Location = new System.Drawing.Point(1194, 670);
            this.ButtonPrint.Name = "ButtonPrint";
            this.ButtonPrint.onHoverState.BorderColor = System.Drawing.Color.White;
            this.ButtonPrint.onHoverState.BorderRadius = 1;
            this.ButtonPrint.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ButtonPrint.onHoverState.BorderThickness = 1;
            this.ButtonPrint.onHoverState.FillColor = System.Drawing.Color.White;
            this.ButtonPrint.onHoverState.ForeColor = System.Drawing.Color.DodgerBlue;
            this.ButtonPrint.onHoverState.IconLeftImage = global::Vender.Properties.Resources.print_1080px;
            this.ButtonPrint.onHoverState.IconRightImage = null;
            this.ButtonPrint.OnIdleState.BorderColor = System.Drawing.Color.WhiteSmoke;
            this.ButtonPrint.OnIdleState.BorderRadius = 1;
            this.ButtonPrint.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ButtonPrint.OnIdleState.BorderThickness = 1;
            this.ButtonPrint.OnIdleState.FillColor = System.Drawing.Color.WhiteSmoke;
            this.ButtonPrint.OnIdleState.ForeColor = System.Drawing.Color.DimGray;
            this.ButtonPrint.OnIdleState.IconLeftImage = global::Vender.Properties.Resources.print_1080px;
            this.ButtonPrint.OnIdleState.IconRightImage = null;
            this.ButtonPrint.OnPressedState.BorderColor = System.Drawing.Color.WhiteSmoke;
            this.ButtonPrint.OnPressedState.BorderRadius = 1;
            this.ButtonPrint.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ButtonPrint.OnPressedState.BorderThickness = 1;
            this.ButtonPrint.OnPressedState.FillColor = System.Drawing.Color.WhiteSmoke;
            this.ButtonPrint.OnPressedState.ForeColor = System.Drawing.Color.DimGray;
            this.ButtonPrint.OnPressedState.IconLeftImage = null;
            this.ButtonPrint.OnPressedState.IconRightImage = null;
            this.ButtonPrint.Size = new System.Drawing.Size(132, 48);
            this.ButtonPrint.TabIndex = 6;
            this.ButtonPrint.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ButtonPrint.TextMarginLeft = 0;
            this.ButtonPrint.UseDefaultRadiusAndThickness = true;
            this.ButtonPrint.Click += new System.EventHandler(this.ButtonPrint_Click);
            // 
            // bunifuGradientPanel5
            // 
            this.bunifuGradientPanel5.BackColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuGradientPanel5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel5.BackgroundImage")));
            this.bunifuGradientPanel5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel5.Controls.Add(this.DataGridViewSellList);
            this.bunifuGradientPanel5.Controls.Add(this.bunifuGradientPanel6);
            this.bunifuGradientPanel5.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuGradientPanel5.GradientBottomLeft = System.Drawing.Color.WhiteSmoke;
            this.bunifuGradientPanel5.GradientBottomRight = System.Drawing.Color.WhiteSmoke;
            this.bunifuGradientPanel5.GradientTopLeft = System.Drawing.Color.WhiteSmoke;
            this.bunifuGradientPanel5.GradientTopRight = System.Drawing.Color.WhiteSmoke;
            this.bunifuGradientPanel5.Location = new System.Drawing.Point(361, 482);
            this.bunifuGradientPanel5.Name = "bunifuGradientPanel5";
            this.bunifuGradientPanel5.Quality = 10;
            this.bunifuGradientPanel5.Size = new System.Drawing.Size(661, 236);
            this.bunifuGradientPanel5.TabIndex = 5;
            // 
            // DataGridViewSellList
            // 
            this.DataGridViewSellList.AllowCustomTheming = false;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.Black;
            this.DataGridViewSellList.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle10;
            this.DataGridViewSellList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DataGridViewSellList.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.DataGridViewSellList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DataGridViewSellList.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.DataGridViewSellList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.DodgerBlue;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DataGridViewSellList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle11;
            this.DataGridViewSellList.ColumnHeadersHeight = 40;
            this.DataGridViewSellList.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            this.DataGridViewSellList.CurrentTheme.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.DataGridViewSellList.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.DataGridViewSellList.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.DataGridViewSellList.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.DataGridViewSellList.CurrentTheme.BackColor = System.Drawing.Color.White;
            this.DataGridViewSellList.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.DataGridViewSellList.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.DodgerBlue;
            this.DataGridViewSellList.CurrentTheme.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            this.DataGridViewSellList.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.DataGridViewSellList.CurrentTheme.HeaderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            this.DataGridViewSellList.CurrentTheme.HeaderStyle.SelectionForeColor = System.Drawing.Color.White;
            this.DataGridViewSellList.CurrentTheme.Name = null;
            this.DataGridViewSellList.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.White;
            this.DataGridViewSellList.CurrentTheme.RowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.DataGridViewSellList.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.DataGridViewSellList.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.DataGridViewSellList.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DataGridViewSellList.DefaultCellStyle = dataGridViewCellStyle12;
            this.DataGridViewSellList.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.DataGridViewSellList.EnableHeadersVisualStyles = false;
            this.DataGridViewSellList.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.DataGridViewSellList.HeaderBackColor = System.Drawing.Color.DodgerBlue;
            this.DataGridViewSellList.HeaderBgColor = System.Drawing.Color.Empty;
            this.DataGridViewSellList.HeaderForeColor = System.Drawing.Color.White;
            this.DataGridViewSellList.Location = new System.Drawing.Point(0, 50);
            this.DataGridViewSellList.Name = "DataGridViewSellList";
            this.DataGridViewSellList.ReadOnly = true;
            this.DataGridViewSellList.RowHeadersVisible = false;
            this.DataGridViewSellList.RowTemplate.Height = 40;
            this.DataGridViewSellList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DataGridViewSellList.Size = new System.Drawing.Size(661, 186);
            this.DataGridViewSellList.TabIndex = 32;
            this.DataGridViewSellList.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Light;
            // 
            // bunifuGradientPanel6
            // 
            this.bunifuGradientPanel6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel6.BackgroundImage")));
            this.bunifuGradientPanel6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel6.Controls.Add(this.bunifuLabel5);
            this.bunifuGradientPanel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.bunifuGradientPanel6.GradientBottomLeft = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(189)))), ((int)(((byte)(241)))));
            this.bunifuGradientPanel6.GradientBottomRight = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(191)))));
            this.bunifuGradientPanel6.GradientTopLeft = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(189)))), ((int)(((byte)(241)))));
            this.bunifuGradientPanel6.GradientTopRight = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(191)))));
            this.bunifuGradientPanel6.Location = new System.Drawing.Point(0, 0);
            this.bunifuGradientPanel6.Name = "bunifuGradientPanel6";
            this.bunifuGradientPanel6.Quality = 10;
            this.bunifuGradientPanel6.Size = new System.Drawing.Size(661, 50);
            this.bunifuGradientPanel6.TabIndex = 0;
            // 
            // bunifuLabel5
            // 
            this.bunifuLabel5.AutoEllipsis = false;
            this.bunifuLabel5.CursorType = null;
            this.bunifuLabel5.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold);
            this.bunifuLabel5.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel5.Location = new System.Drawing.Point(295, 12);
            this.bunifuLabel5.Name = "bunifuLabel5";
            this.bunifuLabel5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel5.Size = new System.Drawing.Size(107, 27);
            this.bunifuLabel5.TabIndex = 0;
            this.bunifuLabel5.Text = "Transaction ";
            this.bunifuLabel5.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel5.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuGradientPanel3
            // 
            this.bunifuGradientPanel3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuGradientPanel3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel3.BackgroundImage")));
            this.bunifuGradientPanel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel3.Controls.Add(this.DataGridViewOrder);
            this.bunifuGradientPanel3.Controls.Add(this.bunifuGradientPanel4);
            this.bunifuGradientPanel3.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuGradientPanel3.GradientBottomLeft = System.Drawing.Color.WhiteSmoke;
            this.bunifuGradientPanel3.GradientBottomRight = System.Drawing.Color.WhiteSmoke;
            this.bunifuGradientPanel3.GradientTopLeft = System.Drawing.Color.WhiteSmoke;
            this.bunifuGradientPanel3.GradientTopRight = System.Drawing.Color.WhiteSmoke;
            this.bunifuGradientPanel3.Location = new System.Drawing.Point(361, 5);
            this.bunifuGradientPanel3.Name = "bunifuGradientPanel3";
            this.bunifuGradientPanel3.Quality = 10;
            this.bunifuGradientPanel3.Size = new System.Drawing.Size(661, 413);
            this.bunifuGradientPanel3.TabIndex = 4;
            // 
            // DataGridViewOrder
            // 
            this.DataGridViewOrder.AllowCustomTheming = false;
            this.DataGridViewOrder.AllowUserToResizeColumns = false;
            this.DataGridViewOrder.AllowUserToResizeRows = false;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle13.ForeColor = System.Drawing.Color.Black;
            this.DataGridViewOrder.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle13;
            this.DataGridViewOrder.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DataGridViewOrder.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.DataGridViewOrder.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DataGridViewOrder.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.DataGridViewOrder.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.DodgerBlue;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle14.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DataGridViewOrder.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle14;
            this.DataGridViewOrder.ColumnHeadersHeight = 40;
            this.DataGridViewOrder.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5});
            this.DataGridViewOrder.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            this.DataGridViewOrder.CurrentTheme.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.DataGridViewOrder.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.DataGridViewOrder.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.DataGridViewOrder.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.DataGridViewOrder.CurrentTheme.BackColor = System.Drawing.Color.White;
            this.DataGridViewOrder.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.DataGridViewOrder.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.DodgerBlue;
            this.DataGridViewOrder.CurrentTheme.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            this.DataGridViewOrder.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.DataGridViewOrder.CurrentTheme.HeaderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            this.DataGridViewOrder.CurrentTheme.HeaderStyle.SelectionForeColor = System.Drawing.Color.White;
            this.DataGridViewOrder.CurrentTheme.Name = null;
            this.DataGridViewOrder.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.White;
            this.DataGridViewOrder.CurrentTheme.RowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.DataGridViewOrder.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.DataGridViewOrder.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.DataGridViewOrder.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle15.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DataGridViewOrder.DefaultCellStyle = dataGridViewCellStyle15;
            this.DataGridViewOrder.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.DataGridViewOrder.EnableHeadersVisualStyles = false;
            this.DataGridViewOrder.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.DataGridViewOrder.HeaderBackColor = System.Drawing.Color.DodgerBlue;
            this.DataGridViewOrder.HeaderBgColor = System.Drawing.Color.Empty;
            this.DataGridViewOrder.HeaderForeColor = System.Drawing.Color.White;
            this.DataGridViewOrder.Location = new System.Drawing.Point(0, 44);
            this.DataGridViewOrder.Name = "DataGridViewOrder";
            this.DataGridViewOrder.ReadOnly = true;
            this.DataGridViewOrder.RowHeadersVisible = false;
            this.DataGridViewOrder.RowHeadersWidth = 20;
            this.DataGridViewOrder.RowTemplate.Height = 40;
            this.DataGridViewOrder.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DataGridViewOrder.Size = new System.Drawing.Size(661, 369);
            this.DataGridViewOrder.TabIndex = 32;
            this.DataGridViewOrder.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Light;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Product ID";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Name";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Price";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Quantity";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Total";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            // 
            // bunifuGradientPanel4
            // 
            this.bunifuGradientPanel4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel4.BackgroundImage")));
            this.bunifuGradientPanel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel4.Controls.Add(this.bunifuLabel4);
            this.bunifuGradientPanel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.bunifuGradientPanel4.GradientBottomLeft = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(189)))), ((int)(((byte)(241)))));
            this.bunifuGradientPanel4.GradientBottomRight = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(191)))));
            this.bunifuGradientPanel4.GradientTopLeft = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(189)))), ((int)(((byte)(241)))));
            this.bunifuGradientPanel4.GradientTopRight = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(191)))));
            this.bunifuGradientPanel4.Location = new System.Drawing.Point(0, 0);
            this.bunifuGradientPanel4.Name = "bunifuGradientPanel4";
            this.bunifuGradientPanel4.Quality = 10;
            this.bunifuGradientPanel4.Size = new System.Drawing.Size(661, 50);
            this.bunifuGradientPanel4.TabIndex = 0;
            // 
            // bunifuLabel4
            // 
            this.bunifuLabel4.AutoEllipsis = false;
            this.bunifuLabel4.CursorType = null;
            this.bunifuLabel4.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold);
            this.bunifuLabel4.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel4.Location = new System.Drawing.Point(295, 8);
            this.bunifuLabel4.Name = "bunifuLabel4";
            this.bunifuLabel4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel4.Size = new System.Drawing.Size(55, 27);
            this.bunifuLabel4.TabIndex = 0;
            this.bunifuLabel4.Text = "Order";
            this.bunifuLabel4.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel4.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.Controls.Add(this.LabelMessage);
            this.bunifuGradientPanel1.Controls.Add(this.ButtonAddOrder);
            this.bunifuGradientPanel1.Controls.Add(this.CategoryDropdown);
            this.bunifuGradientPanel1.Controls.Add(this.DataGridViewProduct);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuLabel3);
            this.bunifuGradientPanel1.Controls.Add(this.ButtonAddSellers);
            this.bunifuGradientPanel1.Controls.Add(this.TextBoxQuantity);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuLabel2);
            this.bunifuGradientPanel1.Controls.Add(this.TextBoxPrice);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuLabel1);
            this.bunifuGradientPanel1.Controls.Add(this.TextBoxName);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuGradientPanel2);
            this.bunifuGradientPanel1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.WhiteSmoke;
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.WhiteSmoke;
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.WhiteSmoke;
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.WhiteSmoke;
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(20, 5);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(322, 713);
            this.bunifuGradientPanel1.TabIndex = 3;
            // 
            // LabelMessage
            // 
            this.LabelMessage.AutoSize = true;
            this.LabelMessage.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelMessage.ForeColor = System.Drawing.Color.Red;
            this.LabelMessage.Location = new System.Drawing.Point(38, 285);
            this.LabelMessage.Name = "LabelMessage";
            this.LabelMessage.Size = new System.Drawing.Size(0, 21);
            this.LabelMessage.TabIndex = 35;
            // 
            // ButtonAddOrder
            // 
            this.ButtonAddOrder.Active = false;
            this.ButtonAddOrder.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            this.ButtonAddOrder.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            this.ButtonAddOrder.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ButtonAddOrder.BorderRadius = 0;
            this.ButtonAddOrder.ButtonText = "Add Order";
            this.ButtonAddOrder.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ButtonAddOrder.DisabledColor = System.Drawing.Color.Gray;
            this.ButtonAddOrder.Iconcolor = System.Drawing.Color.Transparent;
            this.ButtonAddOrder.Iconimage = global::Vender.Properties.Resources.add_1080px;
            this.ButtonAddOrder.Iconimage_right = null;
            this.ButtonAddOrder.Iconimage_right_Selected = null;
            this.ButtonAddOrder.Iconimage_Selected = null;
            this.ButtonAddOrder.IconMarginLeft = 85;
            this.ButtonAddOrder.IconMarginRight = 5;
            this.ButtonAddOrder.IconRightVisible = true;
            this.ButtonAddOrder.IconRightZoom = 0D;
            this.ButtonAddOrder.IconVisible = true;
            this.ButtonAddOrder.IconZoom = 50D;
            this.ButtonAddOrder.IsTab = false;
            this.ButtonAddOrder.Location = new System.Drawing.Point(35, 319);
            this.ButtonAddOrder.Name = "ButtonAddOrder";
            this.ButtonAddOrder.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            this.ButtonAddOrder.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(191)))));
            this.ButtonAddOrder.OnHoverTextColor = System.Drawing.Color.White;
            this.ButtonAddOrder.selected = false;
            this.ButtonAddOrder.Size = new System.Drawing.Size(251, 48);
            this.ButtonAddOrder.TabIndex = 34;
            this.ButtonAddOrder.Text = "Add Order";
            this.ButtonAddOrder.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ButtonAddOrder.Textcolor = System.Drawing.Color.White;
            this.ButtonAddOrder.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonAddOrder.Click += new System.EventHandler(this.ButtonAddOrder_Click);
            // 
            // CategoryDropdown
            // 
            this.CategoryDropdown.BackColor = System.Drawing.Color.WhiteSmoke;
            this.CategoryDropdown.BorderRadius = 1;
            this.CategoryDropdown.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            this.CategoryDropdown.Direction = Bunifu.UI.WinForms.BunifuDropdown.Directions.Down;
            this.CategoryDropdown.DisabledColor = System.Drawing.Color.WhiteSmoke;
            this.CategoryDropdown.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.CategoryDropdown.DropdownBorderThickness = Bunifu.UI.WinForms.BunifuDropdown.BorderThickness.Thick;
            this.CategoryDropdown.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CategoryDropdown.DropDownTextAlign = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left;
            this.CategoryDropdown.FillDropDown = false;
            this.CategoryDropdown.FillIndicator = false;
            this.CategoryDropdown.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CategoryDropdown.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            this.CategoryDropdown.FormattingEnabled = true;
            this.CategoryDropdown.Icon = null;
            this.CategoryDropdown.IndicatorColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            this.CategoryDropdown.IndicatorLocation = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right;
            this.CategoryDropdown.ItemBackColor = System.Drawing.Color.WhiteSmoke;
            this.CategoryDropdown.ItemBorderColor = System.Drawing.Color.WhiteSmoke;
            this.CategoryDropdown.ItemForeColor = System.Drawing.Color.Black;
            this.CategoryDropdown.ItemHeight = 26;
            this.CategoryDropdown.ItemHighLightColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            this.CategoryDropdown.Location = new System.Drawing.Point(35, 381);
            this.CategoryDropdown.Name = "CategoryDropdown";
            this.CategoryDropdown.Size = new System.Drawing.Size(139, 32);
            this.CategoryDropdown.TabIndex = 33;
            this.CategoryDropdown.Text = "Category";
            this.CategoryDropdown.SelectionChangeCommitted += new System.EventHandler(this.CategoryDropdown_SelectionChangeCommitted);
            // 
            // DataGridViewProduct
            // 
            this.DataGridViewProduct.AllowCustomTheming = false;
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle16.ForeColor = System.Drawing.Color.Black;
            this.DataGridViewProduct.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle16;
            this.DataGridViewProduct.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DataGridViewProduct.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.DataGridViewProduct.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DataGridViewProduct.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.DataGridViewProduct.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.DodgerBlue;
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle17.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DataGridViewProduct.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle17;
            this.DataGridViewProduct.ColumnHeadersHeight = 40;
            this.DataGridViewProduct.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            this.DataGridViewProduct.CurrentTheme.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.DataGridViewProduct.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.DataGridViewProduct.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.DataGridViewProduct.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.DataGridViewProduct.CurrentTheme.BackColor = System.Drawing.Color.White;
            this.DataGridViewProduct.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.DataGridViewProduct.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.DodgerBlue;
            this.DataGridViewProduct.CurrentTheme.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            this.DataGridViewProduct.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.DataGridViewProduct.CurrentTheme.HeaderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            this.DataGridViewProduct.CurrentTheme.HeaderStyle.SelectionForeColor = System.Drawing.Color.White;
            this.DataGridViewProduct.CurrentTheme.Name = null;
            this.DataGridViewProduct.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.White;
            this.DataGridViewProduct.CurrentTheme.RowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.DataGridViewProduct.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.DataGridViewProduct.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.DataGridViewProduct.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle18.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DataGridViewProduct.DefaultCellStyle = dataGridViewCellStyle18;
            this.DataGridViewProduct.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.DataGridViewProduct.EnableHeadersVisualStyles = false;
            this.DataGridViewProduct.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.DataGridViewProduct.HeaderBackColor = System.Drawing.Color.DodgerBlue;
            this.DataGridViewProduct.HeaderBgColor = System.Drawing.Color.Empty;
            this.DataGridViewProduct.HeaderForeColor = System.Drawing.Color.White;
            this.DataGridViewProduct.Location = new System.Drawing.Point(0, 440);
            this.DataGridViewProduct.Name = "DataGridViewProduct";
            this.DataGridViewProduct.ReadOnly = true;
            this.DataGridViewProduct.RowHeadersVisible = false;
            this.DataGridViewProduct.RowHeadersWidth = 20;
            this.DataGridViewProduct.RowTemplate.Height = 40;
            this.DataGridViewProduct.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DataGridViewProduct.Size = new System.Drawing.Size(322, 273);
            this.DataGridViewProduct.TabIndex = 32;
            this.DataGridViewProduct.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Light;
            this.DataGridViewProduct.Click += new System.EventHandler(this.DataGridViewProduct_Click);
            // 
            // bunifuLabel3
            // 
            this.bunifuLabel3.AutoEllipsis = false;
            this.bunifuLabel3.CursorType = null;
            this.bunifuLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel3.ForeColor = System.Drawing.Color.DimGray;
            this.bunifuLabel3.Location = new System.Drawing.Point(35, 213);
            this.bunifuLabel3.Name = "bunifuLabel3";
            this.bunifuLabel3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel3.Size = new System.Drawing.Size(65, 20);
            this.bunifuLabel3.TabIndex = 31;
            this.bunifuLabel3.Text = "Quantity";
            this.bunifuLabel3.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel3.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // ButtonAddSellers
            // 
            this.ButtonAddSellers.AllowToggling = false;
            this.ButtonAddSellers.AnimationSpeed = 200;
            this.ButtonAddSellers.AutoGenerateColors = false;
            this.ButtonAddSellers.BackColor = System.Drawing.Color.Transparent;
            this.ButtonAddSellers.BackColor1 = System.Drawing.Color.WhiteSmoke;
            this.ButtonAddSellers.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ButtonAddSellers.BackgroundImage")));
            this.ButtonAddSellers.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ButtonAddSellers.ButtonText = "Refresh";
            this.ButtonAddSellers.ButtonTextMarginLeft = 0;
            this.ButtonAddSellers.ColorContrastOnClick = 45;
            this.ButtonAddSellers.ColorContrastOnHover = 45;
            this.ButtonAddSellers.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges11.BottomLeft = true;
            borderEdges11.BottomRight = true;
            borderEdges11.TopLeft = true;
            borderEdges11.TopRight = true;
            this.ButtonAddSellers.CustomizableEdges = borderEdges11;
            this.ButtonAddSellers.DialogResult = System.Windows.Forms.DialogResult.None;
            this.ButtonAddSellers.DisabledBorderColor = System.Drawing.Color.Empty;
            this.ButtonAddSellers.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.ButtonAddSellers.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.ButtonAddSellers.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.ButtonAddSellers.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.ButtonAddSellers.ForeColor = System.Drawing.Color.DimGray;
            this.ButtonAddSellers.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.ButtonAddSellers.IconMarginLeft = 11;
            this.ButtonAddSellers.IconPadding = 10;
            this.ButtonAddSellers.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.ButtonAddSellers.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            this.ButtonAddSellers.IdleBorderRadius = 1;
            this.ButtonAddSellers.IdleBorderThickness = 1;
            this.ButtonAddSellers.IdleFillColor = System.Drawing.Color.WhiteSmoke;
            this.ButtonAddSellers.IdleIconLeftImage = global::Vender.Properties.Resources.rotate_right_1080px;
            this.ButtonAddSellers.IdleIconRightImage = null;
            this.ButtonAddSellers.IndicateFocus = false;
            this.ButtonAddSellers.Location = new System.Drawing.Point(180, 381);
            this.ButtonAddSellers.Name = "ButtonAddSellers";
            this.ButtonAddSellers.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            this.ButtonAddSellers.onHoverState.BorderRadius = 1;
            this.ButtonAddSellers.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ButtonAddSellers.onHoverState.BorderThickness = 1;
            this.ButtonAddSellers.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            this.ButtonAddSellers.onHoverState.ForeColor = System.Drawing.Color.White;
            this.ButtonAddSellers.onHoverState.IconLeftImage = global::Vender.Properties.Resources.rotate_right_1080px;
            this.ButtonAddSellers.onHoverState.IconRightImage = null;
            this.ButtonAddSellers.OnIdleState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            this.ButtonAddSellers.OnIdleState.BorderRadius = 1;
            this.ButtonAddSellers.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ButtonAddSellers.OnIdleState.BorderThickness = 1;
            this.ButtonAddSellers.OnIdleState.FillColor = System.Drawing.Color.WhiteSmoke;
            this.ButtonAddSellers.OnIdleState.ForeColor = System.Drawing.Color.DimGray;
            this.ButtonAddSellers.OnIdleState.IconLeftImage = global::Vender.Properties.Resources.rotate_right_1080px;
            this.ButtonAddSellers.OnIdleState.IconRightImage = null;
            this.ButtonAddSellers.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            this.ButtonAddSellers.OnPressedState.BorderRadius = 1;
            this.ButtonAddSellers.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ButtonAddSellers.OnPressedState.BorderThickness = 1;
            this.ButtonAddSellers.OnPressedState.FillColor = System.Drawing.Color.WhiteSmoke;
            this.ButtonAddSellers.OnPressedState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            this.ButtonAddSellers.OnPressedState.IconLeftImage = null;
            this.ButtonAddSellers.OnPressedState.IconRightImage = null;
            this.ButtonAddSellers.Size = new System.Drawing.Size(106, 34);
            this.ButtonAddSellers.TabIndex = 26;
            this.ButtonAddSellers.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ButtonAddSellers.TextMarginLeft = 0;
            this.ButtonAddSellers.UseDefaultRadiusAndThickness = true;
            this.ButtonAddSellers.Click += new System.EventHandler(this.ButtonAddSellers_Click);
            // 
            // TextBoxQuantity
            // 
            this.TextBoxQuantity.AcceptsReturn = false;
            this.TextBoxQuantity.AcceptsTab = false;
            this.TextBoxQuantity.AnimationSpeed = 200;
            this.TextBoxQuantity.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.TextBoxQuantity.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.TextBoxQuantity.BackColor = System.Drawing.Color.WhiteSmoke;
            this.TextBoxQuantity.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("TextBoxQuantity.BackgroundImage")));
            this.TextBoxQuantity.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            this.TextBoxQuantity.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            this.TextBoxQuantity.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            this.TextBoxQuantity.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            this.TextBoxQuantity.BorderRadius = 1;
            this.TextBoxQuantity.BorderThickness = 1;
            this.TextBoxQuantity.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.TextBoxQuantity.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxQuantity.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.TextBoxQuantity.DefaultText = "";
            this.TextBoxQuantity.FillColor = System.Drawing.Color.WhiteSmoke;
            this.TextBoxQuantity.ForeColor = System.Drawing.Color.DimGray;
            this.TextBoxQuantity.HideSelection = true;
            this.TextBoxQuantity.IconLeft = null;
            this.TextBoxQuantity.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxQuantity.IconPadding = 10;
            this.TextBoxQuantity.IconRight = null;
            this.TextBoxQuantity.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxQuantity.Lines = new string[0];
            this.TextBoxQuantity.Location = new System.Drawing.Point(35, 239);
            this.TextBoxQuantity.MaxLength = 32767;
            this.TextBoxQuantity.MinimumSize = new System.Drawing.Size(1, 1);
            this.TextBoxQuantity.Modified = false;
            this.TextBoxQuantity.Multiline = false;
            this.TextBoxQuantity.Name = "TextBoxQuantity";
            stateProperties21.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            stateProperties21.FillColor = System.Drawing.Color.Empty;
            stateProperties21.ForeColor = System.Drawing.Color.Empty;
            stateProperties21.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.TextBoxQuantity.OnActiveState = stateProperties21;
            stateProperties22.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            stateProperties22.FillColor = System.Drawing.Color.White;
            stateProperties22.ForeColor = System.Drawing.Color.Empty;
            stateProperties22.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.TextBoxQuantity.OnDisabledState = stateProperties22;
            stateProperties23.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            stateProperties23.FillColor = System.Drawing.Color.Empty;
            stateProperties23.ForeColor = System.Drawing.Color.Empty;
            stateProperties23.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.TextBoxQuantity.OnHoverState = stateProperties23;
            stateProperties24.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            stateProperties24.FillColor = System.Drawing.Color.WhiteSmoke;
            stateProperties24.ForeColor = System.Drawing.Color.DimGray;
            stateProperties24.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.TextBoxQuantity.OnIdleState = stateProperties24;
            this.TextBoxQuantity.PasswordChar = '\0';
            this.TextBoxQuantity.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.TextBoxQuantity.PlaceholderText = "Enter Quantity";
            this.TextBoxQuantity.ReadOnly = false;
            this.TextBoxQuantity.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.TextBoxQuantity.SelectedText = "";
            this.TextBoxQuantity.SelectionLength = 0;
            this.TextBoxQuantity.SelectionStart = 0;
            this.TextBoxQuantity.ShortcutsEnabled = true;
            this.TextBoxQuantity.Size = new System.Drawing.Size(251, 35);
            this.TextBoxQuantity.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Material;
            this.TextBoxQuantity.TabIndex = 30;
            this.TextBoxQuantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.TextBoxQuantity.TextMarginBottom = 0;
            this.TextBoxQuantity.TextMarginLeft = 5;
            this.TextBoxQuantity.TextMarginTop = 0;
            this.TextBoxQuantity.TextPlaceholder = "Enter Quantity";
            this.TextBoxQuantity.UseSystemPasswordChar = false;
            this.TextBoxQuantity.WordWrap = true;
            this.TextBoxQuantity.Click += new System.EventHandler(this.TextBoxQuantity_Click);
            // 
            // bunifuLabel2
            // 
            this.bunifuLabel2.AutoEllipsis = false;
            this.bunifuLabel2.CursorType = null;
            this.bunifuLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel2.ForeColor = System.Drawing.Color.DimGray;
            this.bunifuLabel2.Location = new System.Drawing.Point(35, 146);
            this.bunifuLabel2.Name = "bunifuLabel2";
            this.bunifuLabel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel2.Size = new System.Drawing.Size(42, 20);
            this.bunifuLabel2.TabIndex = 29;
            this.bunifuLabel2.Text = "Price";
            this.bunifuLabel2.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel2.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // TextBoxPrice
            // 
            this.TextBoxPrice.AcceptsReturn = false;
            this.TextBoxPrice.AcceptsTab = false;
            this.TextBoxPrice.AnimationSpeed = 200;
            this.TextBoxPrice.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.TextBoxPrice.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.TextBoxPrice.BackColor = System.Drawing.Color.WhiteSmoke;
            this.TextBoxPrice.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("TextBoxPrice.BackgroundImage")));
            this.TextBoxPrice.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            this.TextBoxPrice.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            this.TextBoxPrice.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            this.TextBoxPrice.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            this.TextBoxPrice.BorderRadius = 1;
            this.TextBoxPrice.BorderThickness = 1;
            this.TextBoxPrice.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.TextBoxPrice.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxPrice.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.TextBoxPrice.DefaultText = "";
            this.TextBoxPrice.FillColor = System.Drawing.Color.WhiteSmoke;
            this.TextBoxPrice.ForeColor = System.Drawing.Color.DimGray;
            this.TextBoxPrice.HideSelection = true;
            this.TextBoxPrice.IconLeft = null;
            this.TextBoxPrice.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxPrice.IconPadding = 10;
            this.TextBoxPrice.IconRight = null;
            this.TextBoxPrice.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxPrice.Lines = new string[0];
            this.TextBoxPrice.Location = new System.Drawing.Point(35, 172);
            this.TextBoxPrice.MaxLength = 32767;
            this.TextBoxPrice.MinimumSize = new System.Drawing.Size(1, 1);
            this.TextBoxPrice.Modified = false;
            this.TextBoxPrice.Multiline = false;
            this.TextBoxPrice.Name = "TextBoxPrice";
            stateProperties25.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            stateProperties25.FillColor = System.Drawing.Color.Empty;
            stateProperties25.ForeColor = System.Drawing.Color.Empty;
            stateProperties25.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.TextBoxPrice.OnActiveState = stateProperties25;
            stateProperties26.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            stateProperties26.FillColor = System.Drawing.Color.White;
            stateProperties26.ForeColor = System.Drawing.Color.Empty;
            stateProperties26.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.TextBoxPrice.OnDisabledState = stateProperties26;
            stateProperties27.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            stateProperties27.FillColor = System.Drawing.Color.Empty;
            stateProperties27.ForeColor = System.Drawing.Color.Empty;
            stateProperties27.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.TextBoxPrice.OnHoverState = stateProperties27;
            stateProperties28.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            stateProperties28.FillColor = System.Drawing.Color.WhiteSmoke;
            stateProperties28.ForeColor = System.Drawing.Color.DimGray;
            stateProperties28.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.TextBoxPrice.OnIdleState = stateProperties28;
            this.TextBoxPrice.PasswordChar = '\0';
            this.TextBoxPrice.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.TextBoxPrice.PlaceholderText = "Price";
            this.TextBoxPrice.ReadOnly = true;
            this.TextBoxPrice.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.TextBoxPrice.SelectedText = "";
            this.TextBoxPrice.SelectionLength = 0;
            this.TextBoxPrice.SelectionStart = 0;
            this.TextBoxPrice.ShortcutsEnabled = true;
            this.TextBoxPrice.Size = new System.Drawing.Size(251, 35);
            this.TextBoxPrice.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Material;
            this.TextBoxPrice.TabIndex = 28;
            this.TextBoxPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.TextBoxPrice.TextMarginBottom = 0;
            this.TextBoxPrice.TextMarginLeft = 5;
            this.TextBoxPrice.TextMarginTop = 0;
            this.TextBoxPrice.TextPlaceholder = "Price";
            this.TextBoxPrice.UseSystemPasswordChar = false;
            this.TextBoxPrice.WordWrap = true;
            // 
            // bunifuLabel1
            // 
            this.bunifuLabel1.AutoEllipsis = false;
            this.bunifuLabel1.CursorType = null;
            this.bunifuLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel1.ForeColor = System.Drawing.Color.DimGray;
            this.bunifuLabel1.Location = new System.Drawing.Point(35, 79);
            this.bunifuLabel1.Name = "bunifuLabel1";
            this.bunifuLabel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel1.Size = new System.Drawing.Size(47, 20);
            this.bunifuLabel1.TabIndex = 27;
            this.bunifuLabel1.Text = "Name";
            this.bunifuLabel1.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel1.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // TextBoxName
            // 
            this.TextBoxName.AcceptsReturn = false;
            this.TextBoxName.AcceptsTab = false;
            this.TextBoxName.AnimationSpeed = 200;
            this.TextBoxName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.TextBoxName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.TextBoxName.BackColor = System.Drawing.Color.WhiteSmoke;
            this.TextBoxName.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("TextBoxName.BackgroundImage")));
            this.TextBoxName.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            this.TextBoxName.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            this.TextBoxName.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            this.TextBoxName.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            this.TextBoxName.BorderRadius = 1;
            this.TextBoxName.BorderThickness = 1;
            this.TextBoxName.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.TextBoxName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxName.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.TextBoxName.DefaultText = "";
            this.TextBoxName.FillColor = System.Drawing.Color.WhiteSmoke;
            this.TextBoxName.ForeColor = System.Drawing.Color.DimGray;
            this.TextBoxName.HideSelection = true;
            this.TextBoxName.IconLeft = null;
            this.TextBoxName.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxName.IconPadding = 10;
            this.TextBoxName.IconRight = null;
            this.TextBoxName.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxName.Lines = new string[0];
            this.TextBoxName.Location = new System.Drawing.Point(35, 105);
            this.TextBoxName.MaxLength = 32767;
            this.TextBoxName.MinimumSize = new System.Drawing.Size(1, 1);
            this.TextBoxName.Modified = false;
            this.TextBoxName.Multiline = false;
            this.TextBoxName.Name = "TextBoxName";
            stateProperties29.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            stateProperties29.FillColor = System.Drawing.Color.Empty;
            stateProperties29.ForeColor = System.Drawing.Color.Empty;
            stateProperties29.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.TextBoxName.OnActiveState = stateProperties29;
            stateProperties30.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            stateProperties30.FillColor = System.Drawing.Color.White;
            stateProperties30.ForeColor = System.Drawing.Color.Empty;
            stateProperties30.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.TextBoxName.OnDisabledState = stateProperties30;
            stateProperties31.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            stateProperties31.FillColor = System.Drawing.Color.Empty;
            stateProperties31.ForeColor = System.Drawing.Color.Empty;
            stateProperties31.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.TextBoxName.OnHoverState = stateProperties31;
            stateProperties32.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(173)))), ((int)(((byte)(239)))));
            stateProperties32.FillColor = System.Drawing.Color.WhiteSmoke;
            stateProperties32.ForeColor = System.Drawing.Color.DimGray;
            stateProperties32.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.TextBoxName.OnIdleState = stateProperties32;
            this.TextBoxName.PasswordChar = '\0';
            this.TextBoxName.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.TextBoxName.PlaceholderText = "Product  Name";
            this.TextBoxName.ReadOnly = true;
            this.TextBoxName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.TextBoxName.SelectedText = "";
            this.TextBoxName.SelectionLength = 0;
            this.TextBoxName.SelectionStart = 0;
            this.TextBoxName.ShortcutsEnabled = true;
            this.TextBoxName.Size = new System.Drawing.Size(251, 35);
            this.TextBoxName.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Material;
            this.TextBoxName.TabIndex = 26;
            this.TextBoxName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.TextBoxName.TextMarginBottom = 0;
            this.TextBoxName.TextMarginLeft = 5;
            this.TextBoxName.TextMarginTop = 0;
            this.TextBoxName.TextPlaceholder = "Product  Name";
            this.TextBoxName.UseSystemPasswordChar = false;
            this.TextBoxName.WordWrap = true;
            this.TextBoxName.Click += new System.EventHandler(this.TextBoxName_Click);
            // 
            // bunifuGradientPanel2
            // 
            this.bunifuGradientPanel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel2.BackgroundImage")));
            this.bunifuGradientPanel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel2.Controls.Add(this.bunifuLabel6);
            this.bunifuGradientPanel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.bunifuGradientPanel2.GradientBottomLeft = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(189)))), ((int)(((byte)(241)))));
            this.bunifuGradientPanel2.GradientBottomRight = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(191)))));
            this.bunifuGradientPanel2.GradientTopLeft = System.Drawing.Color.FromArgb(((int)(((byte)(72)))), ((int)(((byte)(189)))), ((int)(((byte)(241)))));
            this.bunifuGradientPanel2.GradientTopRight = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(107)))), ((int)(((byte)(191)))));
            this.bunifuGradientPanel2.Location = new System.Drawing.Point(0, 0);
            this.bunifuGradientPanel2.Name = "bunifuGradientPanel2";
            this.bunifuGradientPanel2.Quality = 10;
            this.bunifuGradientPanel2.Size = new System.Drawing.Size(322, 50);
            this.bunifuGradientPanel2.TabIndex = 0;
            // 
            // bunifuLabel6
            // 
            this.bunifuLabel6.AutoEllipsis = false;
            this.bunifuLabel6.CursorType = null;
            this.bunifuLabel6.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold);
            this.bunifuLabel6.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel6.Location = new System.Drawing.Point(112, 11);
            this.bunifuLabel6.Name = "bunifuLabel6";
            this.bunifuLabel6.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel6.Size = new System.Drawing.Size(83, 27);
            this.bunifuLabel6.TabIndex = 0;
            this.bunifuLabel6.Text = "Products";
            this.bunifuLabel6.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel6.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // LogoutButton
            // 
            this.LogoutButton.AllowToggling = false;
            this.LogoutButton.AnimationSpeed = 200;
            this.LogoutButton.AutoGenerateColors = false;
            this.LogoutButton.BackColor = System.Drawing.Color.Transparent;
            this.LogoutButton.BackColor1 = System.Drawing.Color.WhiteSmoke;
            this.LogoutButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("LogoutButton.BackgroundImage")));
            this.LogoutButton.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.LogoutButton.ButtonText = "";
            this.LogoutButton.ButtonTextMarginLeft = 0;
            this.LogoutButton.ColorContrastOnClick = 45;
            this.LogoutButton.ColorContrastOnHover = 45;
            this.LogoutButton.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges12.BottomLeft = true;
            borderEdges12.BottomRight = true;
            borderEdges12.TopLeft = true;
            borderEdges12.TopRight = true;
            this.LogoutButton.CustomizableEdges = borderEdges12;
            this.LogoutButton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.LogoutButton.DisabledBorderColor = System.Drawing.Color.Empty;
            this.LogoutButton.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.LogoutButton.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.LogoutButton.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.LogoutButton.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LogoutButton.ForeColor = System.Drawing.Color.DimGray;
            this.LogoutButton.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.LogoutButton.IconMarginLeft = 20;
            this.LogoutButton.IconPadding = 16;
            this.LogoutButton.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.LogoutButton.IdleBorderColor = System.Drawing.Color.WhiteSmoke;
            this.LogoutButton.IdleBorderRadius = 1;
            this.LogoutButton.IdleBorderThickness = 1;
            this.LogoutButton.IdleFillColor = System.Drawing.Color.WhiteSmoke;
            this.LogoutButton.IdleIconLeftImage = global::Vender.Properties.Resources.Logout_1080px;
            this.LogoutButton.IdleIconRightImage = null;
            this.LogoutButton.IndicateFocus = true;
            this.LogoutButton.Location = new System.Drawing.Point(1282, 14);
            this.LogoutButton.Name = "LogoutButton";
            this.LogoutButton.onHoverState.BorderColor = System.Drawing.Color.White;
            this.LogoutButton.onHoverState.BorderRadius = 1;
            this.LogoutButton.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.LogoutButton.onHoverState.BorderThickness = 1;
            this.LogoutButton.onHoverState.FillColor = System.Drawing.Color.White;
            this.LogoutButton.onHoverState.ForeColor = System.Drawing.Color.DodgerBlue;
            this.LogoutButton.onHoverState.IconLeftImage = global::Vender.Properties.Resources.Logout_1080px;
            this.LogoutButton.onHoverState.IconRightImage = null;
            this.LogoutButton.OnIdleState.BorderColor = System.Drawing.Color.WhiteSmoke;
            this.LogoutButton.OnIdleState.BorderRadius = 1;
            this.LogoutButton.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.LogoutButton.OnIdleState.BorderThickness = 1;
            this.LogoutButton.OnIdleState.FillColor = System.Drawing.Color.WhiteSmoke;
            this.LogoutButton.OnIdleState.ForeColor = System.Drawing.Color.DimGray;
            this.LogoutButton.OnIdleState.IconLeftImage = global::Vender.Properties.Resources.Logout_1080px;
            this.LogoutButton.OnIdleState.IconRightImage = null;
            this.LogoutButton.OnPressedState.BorderColor = System.Drawing.Color.White;
            this.LogoutButton.OnPressedState.BorderRadius = 1;
            this.LogoutButton.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.LogoutButton.OnPressedState.BorderThickness = 1;
            this.LogoutButton.OnPressedState.FillColor = System.Drawing.Color.White;
            this.LogoutButton.OnPressedState.ForeColor = System.Drawing.Color.DimGray;
            this.LogoutButton.OnPressedState.IconLeftImage = null;
            this.LogoutButton.OnPressedState.IconRightImage = null;
            this.LogoutButton.Size = new System.Drawing.Size(57, 49);
            this.LogoutButton.TabIndex = 2;
            this.LogoutButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.LogoutButton.TextMarginLeft = 0;
            this.LogoutButton.UseDefaultRadiusAndThickness = true;
            this.LogoutButton.Click += new System.EventHandler(this.LogoutButton_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel1.Controls.Add(this.bunifuImageButton2);
            this.panel1.Controls.Add(this.bunifuImageButton1);
            this.panel1.Controls.Add(this.labelShowSellerName);
            this.panel1.Controls.Add(this.LogoutButton);
            this.panel1.Location = new System.Drawing.Point(-2, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1356, 82);
            this.panel1.TabIndex = 4;
            // 
            // bunifuImageButton2
            // 
            this.bunifuImageButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuImageButton2.Image = global::Vender.Properties.Resources.minimiz;
            this.bunifuImageButton2.ImageActive = null;
            this.bunifuImageButton2.Location = new System.Drawing.Point(1256, 30);
            this.bunifuImageButton2.Name = "bunifuImageButton2";
            this.bunifuImageButton2.Size = new System.Drawing.Size(18, 21);
            this.bunifuImageButton2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton2.TabIndex = 15;
            this.bunifuImageButton2.TabStop = false;
            this.bunifuImageButton2.Zoom = 10;
            this.bunifuImageButton2.Click += new System.EventHandler(this.bunifuImageButton2_Click);
            // 
            // bunifuImageButton1
            // 
            this.bunifuImageButton1.ActiveImage = null;
            this.bunifuImageButton1.AllowAnimations = true;
            this.bunifuImageButton1.AllowBuffering = false;
            this.bunifuImageButton1.AllowZooming = true;
            this.bunifuImageButton1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton1.ErrorImage")));
            this.bunifuImageButton1.FadeWhenInactive = false;
            this.bunifuImageButton1.Flip = Bunifu.UI.WinForms.BunifuImageButton.FlipOrientation.Normal;
            this.bunifuImageButton1.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton1.Image")));
            this.bunifuImageButton1.ImageActive = null;
            this.bunifuImageButton1.ImageLocation = null;
            this.bunifuImageButton1.ImageMargin = 5;
            this.bunifuImageButton1.ImageSize = new System.Drawing.Size(69, 68);
            this.bunifuImageButton1.ImageZoomSize = new System.Drawing.Size(74, 73);
            this.bunifuImageButton1.InitialImage = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton1.InitialImage")));
            this.bunifuImageButton1.Location = new System.Drawing.Point(20, 4);
            this.bunifuImageButton1.Name = "bunifuImageButton1";
            this.bunifuImageButton1.Rotation = 0;
            this.bunifuImageButton1.ShowActiveImage = true;
            this.bunifuImageButton1.ShowCursorChanges = true;
            this.bunifuImageButton1.ShowImageBorders = true;
            this.bunifuImageButton1.ShowSizeMarkers = false;
            this.bunifuImageButton1.Size = new System.Drawing.Size(74, 73);
            this.bunifuImageButton1.TabIndex = 4;
            this.bunifuImageButton1.ToolTipText = "";
            this.bunifuImageButton1.WaitOnLoad = false;
            this.bunifuImageButton1.Zoom = 5;
            this.bunifuImageButton1.ZoomSpeed = 10;
            // 
            // SellingForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1347, 837);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.bunifuShadowPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SellingForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Selling";
            this.Load += new System.EventHandler(this.SellingForm_Load);
            this.bunifuShadowPanel1.ResumeLayout(false);
            this.bunifuShadowPanel1.PerformLayout();
            this.bunifuGradientPanel7.ResumeLayout(false);
            this.bunifuGradientPanel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.bunifuGradientPanel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DataGridViewSellList)).EndInit();
            this.bunifuGradientPanel6.ResumeLayout(false);
            this.bunifuGradientPanel6.PerformLayout();
            this.bunifuGradientPanel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DataGridViewOrder)).EndInit();
            this.bunifuGradientPanel4.ResumeLayout(false);
            this.bunifuGradientPanel4.PerformLayout();
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.bunifuGradientPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridViewProduct)).EndInit();
            this.bunifuGradientPanel2.ResumeLayout(false);
            this.bunifuGradientPanel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.UI.WinForms.BunifuFormDock bunifuFormDock1;
        public System.Windows.Forms.Label labelShowSellerName;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton LogoutButton;
        private Bunifu.UI.WinForm.BunifuShadowPanel.BunifuShadowPanel bunifuShadowPanel1;
        private Bunifu.UI.WinForms.BunifuImageButton bunifuImageButton1;
        private System.Windows.Forms.Panel panel1;
        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel1;
        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel2;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton ButtonAddSellers;
        private Bunifu.UI.WinForms.BunifuDataGridView DataGridViewProduct;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel3;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox TextBoxQuantity;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel2;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox TextBoxPrice;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel1;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox TextBoxName;
        private Bunifu.UI.WinForms.BunifuDropdown CategoryDropdown;
        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel3;
        private Bunifu.UI.WinForms.BunifuDataGridView DataGridViewOrder;
        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel4;
        private Bunifu.Framework.UI.BunifuFlatButton ButtonAddOrder;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton ButtonPrint;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label labelAmount;
        private System.Windows.Forms.Label labelDate;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton ButtonAdd;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator1;
        private Bunifu.Framework.UI.BunifuCustomLabel LabelMessage;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox TextBoxBillID;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Bunifu.Framework.UI.BunifuCustomLabel LabelMessageBill;
        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel5;
        private Bunifu.UI.WinForms.BunifuDataGridView DataGridViewSellList;
        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel6;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel5;
        private Bunifu.UI.WinForms.BunifuDropdown DropdownPrint;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton ButtonClearOrder;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton ButtonRefresh;
        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel7;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton2;
        private System.Windows.Forms.Label LabelTodayAmount;
        private System.Windows.Forms.Label label1;
    }
}