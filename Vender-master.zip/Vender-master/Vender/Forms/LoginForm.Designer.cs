﻿namespace Vender
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Utilities.BunifuPages.BunifuAnimatorNS.Animation animation2 = new Utilities.BunifuPages.BunifuAnimatorNS.Animation();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges7 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties17 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties18 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties19 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties20 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties21 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties22 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties23 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties24 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties25 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties26 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties27 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties28 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges8 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties29 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties30 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties31 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties32 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges6 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges5 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            this.bunifuFormDock1 = new Bunifu.UI.WinForms.BunifuFormDock();
            this.bunifuPages1 = new Bunifu.UI.WinForms.BunifuPages();
            this.SellersPage = new System.Windows.Forms.TabPage();
            this.LabelSellerMessage = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.ButtonLoginSeller = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.ClearButtonSeller = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuLabel2 = new Bunifu.UI.WinForms.BunifuLabel();
            this.TexteBoxPaswordSellerLogin = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.TextBoxUsernameSellerLogin = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.bunifuSeparator1 = new Bunifu.Framework.UI.BunifuSeparator();
            this.bunifuImageButton1 = new Bunifu.Framework.UI.BunifuImageButton();
            this.AdminPage = new System.Windows.Forms.TabPage();
            this.LabelErrorAdmin = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.clearBtn = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuLabel3 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuImageButton2 = new Bunifu.Framework.UI.BunifuImageButton();
            this.TextBoxadminUPassword = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.AdminLoginButton = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.TextBoxadminUsername = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.bunifuSeparator2 = new Bunifu.Framework.UI.BunifuSeparator();
            this.bunifuButton2 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.bunifuButton1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.bunifuGradientPanel1 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.bunifuPages1.SuspendLayout();
            this.SellersPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).BeginInit();
            this.AdminPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton2)).BeginInit();
            this.bunifuGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuFormDock1
            // 
            this.bunifuFormDock1.AllowFormDragging = true;
            this.bunifuFormDock1.AllowFormDropShadow = true;
            this.bunifuFormDock1.AllowFormResizing = false;
            this.bunifuFormDock1.AllowHidingBottomRegion = true;
            this.bunifuFormDock1.AllowOpacityChangesWhileDragging = true;
            this.bunifuFormDock1.BorderOptions.BottomBorder.BorderColor = System.Drawing.Color.Silver;
            this.bunifuFormDock1.BorderOptions.BottomBorder.BorderThickness = 1;
            this.bunifuFormDock1.BorderOptions.BottomBorder.ShowBorder = true;
            this.bunifuFormDock1.BorderOptions.LeftBorder.BorderColor = System.Drawing.Color.Silver;
            this.bunifuFormDock1.BorderOptions.LeftBorder.BorderThickness = 1;
            this.bunifuFormDock1.BorderOptions.LeftBorder.ShowBorder = true;
            this.bunifuFormDock1.BorderOptions.RightBorder.BorderColor = System.Drawing.Color.Silver;
            this.bunifuFormDock1.BorderOptions.RightBorder.BorderThickness = 1;
            this.bunifuFormDock1.BorderOptions.RightBorder.ShowBorder = true;
            this.bunifuFormDock1.BorderOptions.TopBorder.BorderColor = System.Drawing.Color.Silver;
            this.bunifuFormDock1.BorderOptions.TopBorder.BorderThickness = 1;
            this.bunifuFormDock1.BorderOptions.TopBorder.ShowBorder = true;
            this.bunifuFormDock1.ContainerControl = this;
            this.bunifuFormDock1.DockingIndicatorsColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(215)))), ((int)(((byte)(233)))));
            this.bunifuFormDock1.DockingIndicatorsOpacity = 0.5D;
            this.bunifuFormDock1.DockingOptions.DockAll = true;
            this.bunifuFormDock1.DockingOptions.DockBottomLeft = true;
            this.bunifuFormDock1.DockingOptions.DockBottomRight = true;
            this.bunifuFormDock1.DockingOptions.DockFullScreen = true;
            this.bunifuFormDock1.DockingOptions.DockLeft = true;
            this.bunifuFormDock1.DockingOptions.DockRight = true;
            this.bunifuFormDock1.DockingOptions.DockTopLeft = true;
            this.bunifuFormDock1.DockingOptions.DockTopRight = true;
            this.bunifuFormDock1.FormDraggingOpacity = 0.9D;
            this.bunifuFormDock1.ParentForm = this;
            this.bunifuFormDock1.ShowCursorChanges = true;
            this.bunifuFormDock1.ShowDockingIndicators = false;
            this.bunifuFormDock1.TitleBarOptions.AllowFormDragging = true;
            this.bunifuFormDock1.TitleBarOptions.BunifuFormDock = this.bunifuFormDock1;
            this.bunifuFormDock1.TitleBarOptions.DoubleClickToExpandWindow = true;
            this.bunifuFormDock1.TitleBarOptions.TitleBarControl = null;
            this.bunifuFormDock1.TitleBarOptions.UseBackColorOnDockingIndicators = false;
            // 
            // bunifuPages1
            // 
            this.bunifuPages1.Alignment = System.Windows.Forms.TabAlignment.Bottom;
            this.bunifuPages1.AllowTransitions = true;
            this.bunifuPages1.Controls.Add(this.SellersPage);
            this.bunifuPages1.Controls.Add(this.AdminPage);
            this.bunifuPages1.Dock = System.Windows.Forms.DockStyle.Right;
            this.bunifuPages1.Location = new System.Drawing.Point(368, 0);
            this.bunifuPages1.Multiline = true;
            this.bunifuPages1.Name = "bunifuPages1";
            this.bunifuPages1.Page = this.AdminPage;
            this.bunifuPages1.PageIndex = 1;
            this.bunifuPages1.PageName = "AdminPage";
            this.bunifuPages1.PageTitle = "Admin";
            this.bunifuPages1.SelectedIndex = 0;
            this.bunifuPages1.Size = new System.Drawing.Size(409, 396);
            this.bunifuPages1.TabIndex = 1;
            animation2.AnimateOnlyDifferences = true;
            animation2.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation2.BlindCoeff")));
            animation2.LeafCoeff = 0F;
            animation2.MaxTime = 1F;
            animation2.MinTime = 0F;
            animation2.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation2.MosaicCoeff")));
            animation2.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation2.MosaicShift")));
            animation2.MosaicSize = 0;
            animation2.Padding = new System.Windows.Forms.Padding(0, 0, 0, 0);
            animation2.RotateCoeff = 0F;
            animation2.RotateLimit = 0F;
            animation2.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation2.ScaleCoeff")));
            animation2.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation2.SlideCoeff")));
            animation2.TimeCoeff = 0F;
            animation2.TransparencyCoeff = 1F;
            this.bunifuPages1.Transition = animation2;
            this.bunifuPages1.TransitionType = Utilities.BunifuPages.BunifuAnimatorNS.AnimationType.Transparent;
            // 
            // SellersPage
            // 
            this.SellersPage.BackColor = System.Drawing.Color.White;
            this.SellersPage.Controls.Add(this.LabelSellerMessage);
            this.SellersPage.Controls.Add(this.ButtonLoginSeller);
            this.SellersPage.Controls.Add(this.ClearButtonSeller);
            this.SellersPage.Controls.Add(this.bunifuLabel2);
            this.SellersPage.Controls.Add(this.TexteBoxPaswordSellerLogin);
            this.SellersPage.Controls.Add(this.TextBoxUsernameSellerLogin);
            this.SellersPage.Controls.Add(this.bunifuSeparator1);
            this.SellersPage.Controls.Add(this.bunifuImageButton1);
            this.SellersPage.Location = new System.Drawing.Point(4, 4);
            this.SellersPage.Name = "SellersPage";
            this.SellersPage.Padding = new System.Windows.Forms.Padding(3);
            this.SellersPage.Size = new System.Drawing.Size(401, 370);
            this.SellersPage.TabIndex = 0;
            this.SellersPage.Text = "Sellers";
            this.SellersPage.Click += new System.EventHandler(this.SellersPage_Click);
            // 
            // LabelSellerMessage
            // 
            this.LabelSellerMessage.AutoSize = true;
            this.LabelSellerMessage.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelSellerMessage.ForeColor = System.Drawing.Color.Red;
            this.LabelSellerMessage.Location = new System.Drawing.Point(38, 331);
            this.LabelSellerMessage.Name = "LabelSellerMessage";
            this.LabelSellerMessage.Size = new System.Drawing.Size(0, 21);
            this.LabelSellerMessage.TabIndex = 17;
            // 
            // ButtonLoginSeller
            // 
            this.ButtonLoginSeller.AllowToggling = false;
            this.ButtonLoginSeller.AnimationSpeed = 200;
            this.ButtonLoginSeller.AutoGenerateColors = false;
            this.ButtonLoginSeller.BackColor = System.Drawing.Color.Transparent;
            this.ButtonLoginSeller.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.ButtonLoginSeller.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ButtonLoginSeller.BackgroundImage")));
            this.ButtonLoginSeller.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ButtonLoginSeller.ButtonText = "LOGIN";
            this.ButtonLoginSeller.ButtonTextMarginLeft = 0;
            this.ButtonLoginSeller.ColorContrastOnClick = 45;
            this.ButtonLoginSeller.ColorContrastOnHover = 45;
            this.ButtonLoginSeller.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges7.BottomLeft = true;
            borderEdges7.BottomRight = true;
            borderEdges7.TopLeft = true;
            borderEdges7.TopRight = true;
            this.ButtonLoginSeller.CustomizableEdges = borderEdges7;
            this.ButtonLoginSeller.DialogResult = System.Windows.Forms.DialogResult.None;
            this.ButtonLoginSeller.DisabledBorderColor = System.Drawing.Color.Empty;
            this.ButtonLoginSeller.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.ButtonLoginSeller.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.ButtonLoginSeller.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.ButtonLoginSeller.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.ButtonLoginSeller.ForeColor = System.Drawing.Color.White;
            this.ButtonLoginSeller.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.ButtonLoginSeller.IconMarginLeft = 11;
            this.ButtonLoginSeller.IconPadding = 10;
            this.ButtonLoginSeller.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.ButtonLoginSeller.IdleBorderColor = System.Drawing.Color.White;
            this.ButtonLoginSeller.IdleBorderRadius = 30;
            this.ButtonLoginSeller.IdleBorderThickness = 1;
            this.ButtonLoginSeller.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.ButtonLoginSeller.IdleIconLeftImage = null;
            this.ButtonLoginSeller.IdleIconRightImage = null;
            this.ButtonLoginSeller.IndicateFocus = false;
            this.ButtonLoginSeller.Location = new System.Drawing.Point(239, 281);
            this.ButtonLoginSeller.Name = "ButtonLoginSeller";
            this.ButtonLoginSeller.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.ButtonLoginSeller.onHoverState.BorderRadius = 30;
            this.ButtonLoginSeller.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ButtonLoginSeller.onHoverState.BorderThickness = 1;
            this.ButtonLoginSeller.onHoverState.FillColor = System.Drawing.Color.White;
            this.ButtonLoginSeller.onHoverState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.ButtonLoginSeller.onHoverState.IconLeftImage = null;
            this.ButtonLoginSeller.onHoverState.IconRightImage = null;
            this.ButtonLoginSeller.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.ButtonLoginSeller.OnIdleState.BorderRadius = 30;
            this.ButtonLoginSeller.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ButtonLoginSeller.OnIdleState.BorderThickness = 1;
            this.ButtonLoginSeller.OnIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.ButtonLoginSeller.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.ButtonLoginSeller.OnIdleState.IconLeftImage = null;
            this.ButtonLoginSeller.OnIdleState.IconRightImage = null;
            this.ButtonLoginSeller.OnPressedState.BorderColor = System.Drawing.Color.White;
            this.ButtonLoginSeller.OnPressedState.BorderRadius = 30;
            this.ButtonLoginSeller.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ButtonLoginSeller.OnPressedState.BorderThickness = 1;
            this.ButtonLoginSeller.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.ButtonLoginSeller.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.ButtonLoginSeller.OnPressedState.IconLeftImage = null;
            this.ButtonLoginSeller.OnPressedState.IconRightImage = null;
            this.ButtonLoginSeller.Size = new System.Drawing.Size(110, 37);
            this.ButtonLoginSeller.TabIndex = 16;
            this.ButtonLoginSeller.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ButtonLoginSeller.TextMarginLeft = 0;
            this.ButtonLoginSeller.UseDefaultRadiusAndThickness = true;
            this.ButtonLoginSeller.Click += new System.EventHandler(this.ButtonLoginSeller_Click);
            // 
            // ClearButtonSeller
            // 
            this.ClearButtonSeller.ActiveBorderThickness = 1;
            this.ClearButtonSeller.ActiveCornerRadius = 20;
            this.ClearButtonSeller.ActiveFillColor = System.Drawing.Color.White;
            this.ClearButtonSeller.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.ClearButtonSeller.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.ClearButtonSeller.BackColor = System.Drawing.Color.White;
            this.ClearButtonSeller.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ClearButtonSeller.BackgroundImage")));
            this.ClearButtonSeller.ButtonText = "Clear";
            this.ClearButtonSeller.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ClearButtonSeller.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClearButtonSeller.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.ClearButtonSeller.IdleBorderThickness = 1;
            this.ClearButtonSeller.IdleCornerRadius = 30;
            this.ClearButtonSeller.IdleFillColor = System.Drawing.Color.White;
            this.ClearButtonSeller.IdleForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.ClearButtonSeller.IdleLineColor = System.Drawing.Color.White;
            this.ClearButtonSeller.Location = new System.Drawing.Point(128, 278);
            this.ClearButtonSeller.Margin = new System.Windows.Forms.Padding(5);
            this.ClearButtonSeller.Name = "ClearButtonSeller";
            this.ClearButtonSeller.Size = new System.Drawing.Size(103, 44);
            this.ClearButtonSeller.TabIndex = 15;
            this.ClearButtonSeller.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ClearButtonSeller.Click += new System.EventHandler(this.ClearButtonSeller_Click);
            // 
            // bunifuLabel2
            // 
            this.bunifuLabel2.AutoEllipsis = false;
            this.bunifuLabel2.CursorType = null;
            this.bunifuLabel2.Font = new System.Drawing.Font("Segoe UI Black", 14.25F, System.Drawing.FontStyle.Bold);
            this.bunifuLabel2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.bunifuLabel2.Location = new System.Drawing.Point(153, 61);
            this.bunifuLabel2.Name = "bunifuLabel2";
            this.bunifuLabel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel2.Size = new System.Drawing.Size(78, 27);
            this.bunifuLabel2.TabIndex = 4;
            this.bunifuLabel2.Text = "SELLERS";
            this.bunifuLabel2.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel2.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // TexteBoxPaswordSellerLogin
            // 
            this.TexteBoxPaswordSellerLogin.AcceptsReturn = false;
            this.TexteBoxPaswordSellerLogin.AcceptsTab = false;
            this.TexteBoxPaswordSellerLogin.AnimationSpeed = 200;
            this.TexteBoxPaswordSellerLogin.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.TexteBoxPaswordSellerLogin.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.TexteBoxPaswordSellerLogin.BackColor = System.Drawing.Color.Transparent;
            this.TexteBoxPaswordSellerLogin.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("TexteBoxPaswordSellerLogin.BackgroundImage")));
            this.TexteBoxPaswordSellerLogin.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.TexteBoxPaswordSellerLogin.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.TexteBoxPaswordSellerLogin.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.TexteBoxPaswordSellerLogin.BorderColorIdle = System.Drawing.Color.Silver;
            this.TexteBoxPaswordSellerLogin.BorderRadius = 1;
            this.TexteBoxPaswordSellerLogin.BorderThickness = 1;
            this.TexteBoxPaswordSellerLogin.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.TexteBoxPaswordSellerLogin.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TexteBoxPaswordSellerLogin.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.TexteBoxPaswordSellerLogin.DefaultText = "";
            this.TexteBoxPaswordSellerLogin.FillColor = System.Drawing.Color.White;
            this.TexteBoxPaswordSellerLogin.HideSelection = true;
            this.TexteBoxPaswordSellerLogin.IconLeft = global::Vender.Properties.Resources.password_144px;
            this.TexteBoxPaswordSellerLogin.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.TexteBoxPaswordSellerLogin.IconPadding = 10;
            this.TexteBoxPaswordSellerLogin.IconRight = null;
            this.TexteBoxPaswordSellerLogin.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.TexteBoxPaswordSellerLogin.Lines = new string[0];
            this.TexteBoxPaswordSellerLogin.Location = new System.Drawing.Point(42, 219);
            this.TexteBoxPaswordSellerLogin.MaxLength = 32767;
            this.TexteBoxPaswordSellerLogin.MinimumSize = new System.Drawing.Size(1, 1);
            this.TexteBoxPaswordSellerLogin.Modified = false;
            this.TexteBoxPaswordSellerLogin.Multiline = false;
            this.TexteBoxPaswordSellerLogin.Name = "TexteBoxPaswordSellerLogin";
            stateProperties17.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            stateProperties17.FillColor = System.Drawing.Color.Empty;
            stateProperties17.ForeColor = System.Drawing.Color.Empty;
            stateProperties17.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.TexteBoxPaswordSellerLogin.OnActiveState = stateProperties17;
            stateProperties18.BorderColor = System.Drawing.Color.Empty;
            stateProperties18.FillColor = System.Drawing.Color.White;
            stateProperties18.ForeColor = System.Drawing.Color.Empty;
            stateProperties18.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.TexteBoxPaswordSellerLogin.OnDisabledState = stateProperties18;
            stateProperties19.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            stateProperties19.FillColor = System.Drawing.Color.Empty;
            stateProperties19.ForeColor = System.Drawing.Color.Empty;
            stateProperties19.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.TexteBoxPaswordSellerLogin.OnHoverState = stateProperties19;
            stateProperties20.BorderColor = System.Drawing.Color.Silver;
            stateProperties20.FillColor = System.Drawing.Color.White;
            stateProperties20.ForeColor = System.Drawing.Color.Empty;
            stateProperties20.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.TexteBoxPaswordSellerLogin.OnIdleState = stateProperties20;
            this.TexteBoxPaswordSellerLogin.PasswordChar = '*';
            this.TexteBoxPaswordSellerLogin.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.TexteBoxPaswordSellerLogin.PlaceholderText = "Password";
            this.TexteBoxPaswordSellerLogin.ReadOnly = false;
            this.TexteBoxPaswordSellerLogin.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.TexteBoxPaswordSellerLogin.SelectedText = "";
            this.TexteBoxPaswordSellerLogin.SelectionLength = 0;
            this.TexteBoxPaswordSellerLogin.SelectionStart = 0;
            this.TexteBoxPaswordSellerLogin.ShortcutsEnabled = true;
            this.TexteBoxPaswordSellerLogin.Size = new System.Drawing.Size(307, 35);
            this.TexteBoxPaswordSellerLogin.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.TexteBoxPaswordSellerLogin.TabIndex = 6;
            this.TexteBoxPaswordSellerLogin.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.TexteBoxPaswordSellerLogin.TextMarginBottom = 0;
            this.TexteBoxPaswordSellerLogin.TextMarginLeft = 5;
            this.TexteBoxPaswordSellerLogin.TextMarginTop = 0;
            this.TexteBoxPaswordSellerLogin.TextPlaceholder = "Password";
            this.TexteBoxPaswordSellerLogin.UseSystemPasswordChar = false;
            this.TexteBoxPaswordSellerLogin.WordWrap = true;
            this.TexteBoxPaswordSellerLogin.TextChanged += new System.EventHandler(this.TexteBoxPaswordSellerLogin_TextChanged);
            this.TexteBoxPaswordSellerLogin.Click += new System.EventHandler(this.TexteBoxPaswordSellerLogin_Click);
            // 
            // TextBoxUsernameSellerLogin
            // 
            this.TextBoxUsernameSellerLogin.AcceptsReturn = false;
            this.TextBoxUsernameSellerLogin.AcceptsTab = false;
            this.TextBoxUsernameSellerLogin.AnimationSpeed = 200;
            this.TextBoxUsernameSellerLogin.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.TextBoxUsernameSellerLogin.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.TextBoxUsernameSellerLogin.BackColor = System.Drawing.Color.Transparent;
            this.TextBoxUsernameSellerLogin.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("TextBoxUsernameSellerLogin.BackgroundImage")));
            this.TextBoxUsernameSellerLogin.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.TextBoxUsernameSellerLogin.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.TextBoxUsernameSellerLogin.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.TextBoxUsernameSellerLogin.BorderColorIdle = System.Drawing.Color.Silver;
            this.TextBoxUsernameSellerLogin.BorderRadius = 1;
            this.TextBoxUsernameSellerLogin.BorderThickness = 1;
            this.TextBoxUsernameSellerLogin.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.TextBoxUsernameSellerLogin.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxUsernameSellerLogin.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.TextBoxUsernameSellerLogin.DefaultText = "";
            this.TextBoxUsernameSellerLogin.FillColor = System.Drawing.Color.White;
            this.TextBoxUsernameSellerLogin.HideSelection = true;
            this.TextBoxUsernameSellerLogin.IconLeft = global::Vender.Properties.Resources.user_512px;
            this.TextBoxUsernameSellerLogin.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxUsernameSellerLogin.IconPadding = 10;
            this.TextBoxUsernameSellerLogin.IconRight = null;
            this.TextBoxUsernameSellerLogin.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxUsernameSellerLogin.Lines = new string[0];
            this.TextBoxUsernameSellerLogin.Location = new System.Drawing.Point(42, 153);
            this.TextBoxUsernameSellerLogin.MaxLength = 32767;
            this.TextBoxUsernameSellerLogin.MinimumSize = new System.Drawing.Size(1, 1);
            this.TextBoxUsernameSellerLogin.Modified = false;
            this.TextBoxUsernameSellerLogin.Multiline = false;
            this.TextBoxUsernameSellerLogin.Name = "TextBoxUsernameSellerLogin";
            stateProperties21.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            stateProperties21.FillColor = System.Drawing.Color.Empty;
            stateProperties21.ForeColor = System.Drawing.Color.Empty;
            stateProperties21.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.TextBoxUsernameSellerLogin.OnActiveState = stateProperties21;
            stateProperties22.BorderColor = System.Drawing.Color.Empty;
            stateProperties22.FillColor = System.Drawing.Color.White;
            stateProperties22.ForeColor = System.Drawing.Color.Empty;
            stateProperties22.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.TextBoxUsernameSellerLogin.OnDisabledState = stateProperties22;
            stateProperties23.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            stateProperties23.FillColor = System.Drawing.Color.Empty;
            stateProperties23.ForeColor = System.Drawing.Color.Empty;
            stateProperties23.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.TextBoxUsernameSellerLogin.OnHoverState = stateProperties23;
            stateProperties24.BorderColor = System.Drawing.Color.Silver;
            stateProperties24.FillColor = System.Drawing.Color.White;
            stateProperties24.ForeColor = System.Drawing.Color.Empty;
            stateProperties24.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.TextBoxUsernameSellerLogin.OnIdleState = stateProperties24;
            this.TextBoxUsernameSellerLogin.PasswordChar = '\0';
            this.TextBoxUsernameSellerLogin.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.TextBoxUsernameSellerLogin.PlaceholderText = "Username";
            this.TextBoxUsernameSellerLogin.ReadOnly = false;
            this.TextBoxUsernameSellerLogin.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.TextBoxUsernameSellerLogin.SelectedText = "";
            this.TextBoxUsernameSellerLogin.SelectionLength = 0;
            this.TextBoxUsernameSellerLogin.SelectionStart = 0;
            this.TextBoxUsernameSellerLogin.ShortcutsEnabled = true;
            this.TextBoxUsernameSellerLogin.Size = new System.Drawing.Size(307, 35);
            this.TextBoxUsernameSellerLogin.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.TextBoxUsernameSellerLogin.TabIndex = 6;
            this.TextBoxUsernameSellerLogin.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.TextBoxUsernameSellerLogin.TextMarginBottom = 0;
            this.TextBoxUsernameSellerLogin.TextMarginLeft = 5;
            this.TextBoxUsernameSellerLogin.TextMarginTop = 0;
            this.TextBoxUsernameSellerLogin.TextPlaceholder = "Username";
            this.TextBoxUsernameSellerLogin.UseSystemPasswordChar = false;
            this.TextBoxUsernameSellerLogin.WordWrap = true;
            this.TextBoxUsernameSellerLogin.TextChanged += new System.EventHandler(this.TextBoxUsernameSellerLogin_TextChanged);
            this.TextBoxUsernameSellerLogin.Click += new System.EventHandler(this.TextBoxUsernameSellerLogin_Click);
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.bunifuSeparator1.LineThickness = 1;
            this.bunifuSeparator1.Location = new System.Drawing.Point(145, 87);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Size = new System.Drawing.Size(95, 35);
            this.bunifuSeparator1.TabIndex = 5;
            this.bunifuSeparator1.Transparency = 255;
            this.bunifuSeparator1.Vertical = false;
            // 
            // bunifuImageButton1
            // 
            this.bunifuImageButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuImageButton1.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton1.Image")));
            this.bunifuImageButton1.ImageActive = null;
            this.bunifuImageButton1.Location = new System.Drawing.Point(369, 9);
            this.bunifuImageButton1.Name = "bunifuImageButton1";
            this.bunifuImageButton1.Size = new System.Drawing.Size(32, 21);
            this.bunifuImageButton1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton1.TabIndex = 1;
            this.bunifuImageButton1.TabStop = false;
            this.bunifuImageButton1.Zoom = 10;
            this.bunifuImageButton1.Click += new System.EventHandler(this.bunifuImageButton1_Click);
            // 
            // AdminPage
            // 
            this.AdminPage.BackColor = System.Drawing.Color.White;
            this.AdminPage.Controls.Add(this.LabelErrorAdmin);
            this.AdminPage.Controls.Add(this.clearBtn);
            this.AdminPage.Controls.Add(this.bunifuLabel3);
            this.AdminPage.Controls.Add(this.bunifuImageButton2);
            this.AdminPage.Controls.Add(this.TextBoxadminUPassword);
            this.AdminPage.Controls.Add(this.AdminLoginButton);
            this.AdminPage.Controls.Add(this.TextBoxadminUsername);
            this.AdminPage.Controls.Add(this.bunifuSeparator2);
            this.AdminPage.Location = new System.Drawing.Point(4, 4);
            this.AdminPage.Name = "AdminPage";
            this.AdminPage.Padding = new System.Windows.Forms.Padding(3);
            this.AdminPage.Size = new System.Drawing.Size(401, 370);
            this.AdminPage.TabIndex = 1;
            this.AdminPage.Text = "Admin";
            this.AdminPage.Click += new System.EventHandler(this.AdminPage_Click);
            // 
            // LabelErrorAdmin
            // 
            this.LabelErrorAdmin.AutoSize = true;
            this.LabelErrorAdmin.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelErrorAdmin.ForeColor = System.Drawing.Color.Red;
            this.LabelErrorAdmin.Location = new System.Drawing.Point(42, 330);
            this.LabelErrorAdmin.Name = "LabelErrorAdmin";
            this.LabelErrorAdmin.Size = new System.Drawing.Size(0, 21);
            this.LabelErrorAdmin.TabIndex = 14;
            // 
            // clearBtn
            // 
            this.clearBtn.ActiveBorderThickness = 1;
            this.clearBtn.ActiveCornerRadius = 20;
            this.clearBtn.ActiveFillColor = System.Drawing.Color.White;
            this.clearBtn.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.clearBtn.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.clearBtn.BackColor = System.Drawing.Color.White;
            this.clearBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("clearBtn.BackgroundImage")));
            this.clearBtn.ButtonText = "Clear";
            this.clearBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.clearBtn.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.clearBtn.IdleBorderThickness = 1;
            this.clearBtn.IdleCornerRadius = 30;
            this.clearBtn.IdleFillColor = System.Drawing.Color.White;
            this.clearBtn.IdleForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.clearBtn.IdleLineColor = System.Drawing.Color.White;
            this.clearBtn.Location = new System.Drawing.Point(127, 249);
            this.clearBtn.Margin = new System.Windows.Forms.Padding(5);
            this.clearBtn.Name = "clearBtn";
            this.clearBtn.Size = new System.Drawing.Size(103, 44);
            this.clearBtn.TabIndex = 13;
            this.clearBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.clearBtn.Click += new System.EventHandler(this.clearBtn_Click);
            // 
            // bunifuLabel3
            // 
            this.bunifuLabel3.AutoEllipsis = false;
            this.bunifuLabel3.CursorType = null;
            this.bunifuLabel3.Font = new System.Drawing.Font("Segoe UI Black", 14.25F, System.Drawing.FontStyle.Bold);
            this.bunifuLabel3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.bunifuLabel3.Location = new System.Drawing.Point(158, 45);
            this.bunifuLabel3.Name = "bunifuLabel3";
            this.bunifuLabel3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel3.Size = new System.Drawing.Size(72, 27);
            this.bunifuLabel3.TabIndex = 8;
            this.bunifuLabel3.Text = "ADMIN";
            this.bunifuLabel3.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel3.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuImageButton2
            // 
            this.bunifuImageButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuImageButton2.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton2.Image")));
            this.bunifuImageButton2.ImageActive = null;
            this.bunifuImageButton2.Location = new System.Drawing.Point(369, 9);
            this.bunifuImageButton2.Name = "bunifuImageButton2";
            this.bunifuImageButton2.Size = new System.Drawing.Size(32, 21);
            this.bunifuImageButton2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton2.TabIndex = 12;
            this.bunifuImageButton2.TabStop = false;
            this.bunifuImageButton2.Zoom = 10;
            this.bunifuImageButton2.Click += new System.EventHandler(this.bunifuImageButton2_Click);
            // 
            // TextBoxadminUPassword
            // 
            this.TextBoxadminUPassword.AcceptsReturn = false;
            this.TextBoxadminUPassword.AcceptsTab = false;
            this.TextBoxadminUPassword.AnimationSpeed = 200;
            this.TextBoxadminUPassword.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.TextBoxadminUPassword.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.TextBoxadminUPassword.BackColor = System.Drawing.Color.Transparent;
            this.TextBoxadminUPassword.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("TextBoxadminUPassword.BackgroundImage")));
            this.TextBoxadminUPassword.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.TextBoxadminUPassword.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.TextBoxadminUPassword.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.TextBoxadminUPassword.BorderColorIdle = System.Drawing.Color.Silver;
            this.TextBoxadminUPassword.BorderRadius = 1;
            this.TextBoxadminUPassword.BorderThickness = 1;
            this.TextBoxadminUPassword.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.TextBoxadminUPassword.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxadminUPassword.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.TextBoxadminUPassword.DefaultText = "";
            this.TextBoxadminUPassword.FillColor = System.Drawing.Color.White;
            this.TextBoxadminUPassword.HideSelection = true;
            this.TextBoxadminUPassword.IconLeft = global::Vender.Properties.Resources.password_144px;
            this.TextBoxadminUPassword.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxadminUPassword.IconPadding = 10;
            this.TextBoxadminUPassword.IconRight = null;
            this.TextBoxadminUPassword.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxadminUPassword.Lines = new string[0];
            this.TextBoxadminUPassword.Location = new System.Drawing.Point(42, 190);
            this.TextBoxadminUPassword.MaxLength = 32767;
            this.TextBoxadminUPassword.MinimumSize = new System.Drawing.Size(1, 1);
            this.TextBoxadminUPassword.Modified = false;
            this.TextBoxadminUPassword.Multiline = false;
            this.TextBoxadminUPassword.Name = "TextBoxadminUPassword";
            stateProperties25.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            stateProperties25.FillColor = System.Drawing.Color.Empty;
            stateProperties25.ForeColor = System.Drawing.Color.Empty;
            stateProperties25.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.TextBoxadminUPassword.OnActiveState = stateProperties25;
            stateProperties26.BorderColor = System.Drawing.Color.Empty;
            stateProperties26.FillColor = System.Drawing.Color.White;
            stateProperties26.ForeColor = System.Drawing.Color.Empty;
            stateProperties26.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.TextBoxadminUPassword.OnDisabledState = stateProperties26;
            stateProperties27.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            stateProperties27.FillColor = System.Drawing.Color.Empty;
            stateProperties27.ForeColor = System.Drawing.Color.Empty;
            stateProperties27.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.TextBoxadminUPassword.OnHoverState = stateProperties27;
            stateProperties28.BorderColor = System.Drawing.Color.Silver;
            stateProperties28.FillColor = System.Drawing.Color.White;
            stateProperties28.ForeColor = System.Drawing.Color.Empty;
            stateProperties28.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.TextBoxadminUPassword.OnIdleState = stateProperties28;
            this.TextBoxadminUPassword.PasswordChar = '*';
            this.TextBoxadminUPassword.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.TextBoxadminUPassword.PlaceholderText = "Password";
            this.TextBoxadminUPassword.ReadOnly = false;
            this.TextBoxadminUPassword.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.TextBoxadminUPassword.SelectedText = "";
            this.TextBoxadminUPassword.SelectionLength = 0;
            this.TextBoxadminUPassword.SelectionStart = 0;
            this.TextBoxadminUPassword.ShortcutsEnabled = true;
            this.TextBoxadminUPassword.Size = new System.Drawing.Size(307, 35);
            this.TextBoxadminUPassword.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.TextBoxadminUPassword.TabIndex = 10;
            this.TextBoxadminUPassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.TextBoxadminUPassword.TextMarginBottom = 0;
            this.TextBoxadminUPassword.TextMarginLeft = 5;
            this.TextBoxadminUPassword.TextMarginTop = 0;
            this.TextBoxadminUPassword.TextPlaceholder = "Password";
            this.TextBoxadminUPassword.UseSystemPasswordChar = false;
            this.TextBoxadminUPassword.WordWrap = true;
            this.TextBoxadminUPassword.Click += new System.EventHandler(this.TextBoxadminUPassword_Click);
            // 
            // AdminLoginButton
            // 
            this.AdminLoginButton.AllowToggling = false;
            this.AdminLoginButton.AnimationSpeed = 200;
            this.AdminLoginButton.AutoGenerateColors = false;
            this.AdminLoginButton.BackColor = System.Drawing.Color.Transparent;
            this.AdminLoginButton.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.AdminLoginButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("AdminLoginButton.BackgroundImage")));
            this.AdminLoginButton.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.AdminLoginButton.ButtonText = "LOGIN";
            this.AdminLoginButton.ButtonTextMarginLeft = 0;
            this.AdminLoginButton.ColorContrastOnClick = 45;
            this.AdminLoginButton.ColorContrastOnHover = 45;
            this.AdminLoginButton.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges8.BottomLeft = true;
            borderEdges8.BottomRight = true;
            borderEdges8.TopLeft = true;
            borderEdges8.TopRight = true;
            this.AdminLoginButton.CustomizableEdges = borderEdges8;
            this.AdminLoginButton.DialogResult = System.Windows.Forms.DialogResult.None;
            this.AdminLoginButton.DisabledBorderColor = System.Drawing.Color.Empty;
            this.AdminLoginButton.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.AdminLoginButton.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.AdminLoginButton.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.AdminLoginButton.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.AdminLoginButton.ForeColor = System.Drawing.Color.White;
            this.AdminLoginButton.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.AdminLoginButton.IconMarginLeft = 11;
            this.AdminLoginButton.IconPadding = 10;
            this.AdminLoginButton.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.AdminLoginButton.IdleBorderColor = System.Drawing.Color.White;
            this.AdminLoginButton.IdleBorderRadius = 30;
            this.AdminLoginButton.IdleBorderThickness = 1;
            this.AdminLoginButton.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.AdminLoginButton.IdleIconLeftImage = null;
            this.AdminLoginButton.IdleIconRightImage = null;
            this.AdminLoginButton.IndicateFocus = false;
            this.AdminLoginButton.Location = new System.Drawing.Point(239, 251);
            this.AdminLoginButton.Name = "AdminLoginButton";
            this.AdminLoginButton.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.AdminLoginButton.onHoverState.BorderRadius = 30;
            this.AdminLoginButton.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.AdminLoginButton.onHoverState.BorderThickness = 1;
            this.AdminLoginButton.onHoverState.FillColor = System.Drawing.Color.White;
            this.AdminLoginButton.onHoverState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.AdminLoginButton.onHoverState.IconLeftImage = null;
            this.AdminLoginButton.onHoverState.IconRightImage = null;
            this.AdminLoginButton.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.AdminLoginButton.OnIdleState.BorderRadius = 30;
            this.AdminLoginButton.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.AdminLoginButton.OnIdleState.BorderThickness = 1;
            this.AdminLoginButton.OnIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.AdminLoginButton.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.AdminLoginButton.OnIdleState.IconLeftImage = null;
            this.AdminLoginButton.OnIdleState.IconRightImage = null;
            this.AdminLoginButton.OnPressedState.BorderColor = System.Drawing.Color.White;
            this.AdminLoginButton.OnPressedState.BorderRadius = 30;
            this.AdminLoginButton.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.AdminLoginButton.OnPressedState.BorderThickness = 1;
            this.AdminLoginButton.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.AdminLoginButton.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.AdminLoginButton.OnPressedState.IconLeftImage = null;
            this.AdminLoginButton.OnPressedState.IconRightImage = null;
            this.AdminLoginButton.Size = new System.Drawing.Size(110, 37);
            this.AdminLoginButton.TabIndex = 7;
            this.AdminLoginButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.AdminLoginButton.TextMarginLeft = 0;
            this.AdminLoginButton.UseDefaultRadiusAndThickness = true;
            this.AdminLoginButton.Click += new System.EventHandler(this.AdminLoginButton_Click);
            // 
            // TextBoxadminUsername
            // 
            this.TextBoxadminUsername.AcceptsReturn = false;
            this.TextBoxadminUsername.AcceptsTab = false;
            this.TextBoxadminUsername.AnimationSpeed = 200;
            this.TextBoxadminUsername.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.TextBoxadminUsername.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.TextBoxadminUsername.BackColor = System.Drawing.Color.Transparent;
            this.TextBoxadminUsername.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("TextBoxadminUsername.BackgroundImage")));
            this.TextBoxadminUsername.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.TextBoxadminUsername.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.TextBoxadminUsername.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.TextBoxadminUsername.BorderColorIdle = System.Drawing.Color.Silver;
            this.TextBoxadminUsername.BorderRadius = 1;
            this.TextBoxadminUsername.BorderThickness = 1;
            this.TextBoxadminUsername.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.TextBoxadminUsername.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxadminUsername.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.TextBoxadminUsername.DefaultText = "";
            this.TextBoxadminUsername.FillColor = System.Drawing.Color.White;
            this.TextBoxadminUsername.HideSelection = true;
            this.TextBoxadminUsername.IconLeft = global::Vender.Properties.Resources.user_512px;
            this.TextBoxadminUsername.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxadminUsername.IconPadding = 10;
            this.TextBoxadminUsername.IconRight = null;
            this.TextBoxadminUsername.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxadminUsername.Lines = new string[0];
            this.TextBoxadminUsername.Location = new System.Drawing.Point(42, 124);
            this.TextBoxadminUsername.MaxLength = 32767;
            this.TextBoxadminUsername.MinimumSize = new System.Drawing.Size(1, 1);
            this.TextBoxadminUsername.Modified = false;
            this.TextBoxadminUsername.Multiline = false;
            this.TextBoxadminUsername.Name = "TextBoxadminUsername";
            stateProperties29.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            stateProperties29.FillColor = System.Drawing.Color.Empty;
            stateProperties29.ForeColor = System.Drawing.Color.Empty;
            stateProperties29.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.TextBoxadminUsername.OnActiveState = stateProperties29;
            stateProperties30.BorderColor = System.Drawing.Color.Empty;
            stateProperties30.FillColor = System.Drawing.Color.White;
            stateProperties30.ForeColor = System.Drawing.Color.Empty;
            stateProperties30.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.TextBoxadminUsername.OnDisabledState = stateProperties30;
            stateProperties31.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            stateProperties31.FillColor = System.Drawing.Color.Empty;
            stateProperties31.ForeColor = System.Drawing.Color.Empty;
            stateProperties31.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.TextBoxadminUsername.OnHoverState = stateProperties31;
            stateProperties32.BorderColor = System.Drawing.Color.Silver;
            stateProperties32.FillColor = System.Drawing.Color.White;
            stateProperties32.ForeColor = System.Drawing.Color.Empty;
            stateProperties32.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.TextBoxadminUsername.OnIdleState = stateProperties32;
            this.TextBoxadminUsername.PasswordChar = '\0';
            this.TextBoxadminUsername.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.TextBoxadminUsername.PlaceholderText = "Username";
            this.TextBoxadminUsername.ReadOnly = false;
            this.TextBoxadminUsername.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.TextBoxadminUsername.SelectedText = "";
            this.TextBoxadminUsername.SelectionLength = 0;
            this.TextBoxadminUsername.SelectionStart = 0;
            this.TextBoxadminUsername.ShortcutsEnabled = true;
            this.TextBoxadminUsername.Size = new System.Drawing.Size(307, 35);
            this.TextBoxadminUsername.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.TextBoxadminUsername.TabIndex = 11;
            this.TextBoxadminUsername.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.TextBoxadminUsername.TextMarginBottom = 0;
            this.TextBoxadminUsername.TextMarginLeft = 5;
            this.TextBoxadminUsername.TextMarginTop = 0;
            this.TextBoxadminUsername.TextPlaceholder = "Username";
            this.TextBoxadminUsername.UseSystemPasswordChar = false;
            this.TextBoxadminUsername.WordWrap = true;
            this.TextBoxadminUsername.MouseClick += new System.Windows.Forms.MouseEventHandler(this.TextBoxadminUsername_MouseClick);
            // 
            // bunifuSeparator2
            // 
            this.bunifuSeparator2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator2.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.bunifuSeparator2.LineThickness = 1;
            this.bunifuSeparator2.Location = new System.Drawing.Point(147, 70);
            this.bunifuSeparator2.Name = "bunifuSeparator2";
            this.bunifuSeparator2.Size = new System.Drawing.Size(97, 35);
            this.bunifuSeparator2.TabIndex = 9;
            this.bunifuSeparator2.Transparency = 255;
            this.bunifuSeparator2.Vertical = false;
            // 
            // bunifuButton2
            // 
            this.bunifuButton2.AllowToggling = false;
            this.bunifuButton2.AnimationSpeed = 200;
            this.bunifuButton2.AutoGenerateColors = false;
            this.bunifuButton2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton2.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.bunifuButton2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton2.BackgroundImage")));
            this.bunifuButton2.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton2.ButtonText = "SELLERS";
            this.bunifuButton2.ButtonTextMarginLeft = 0;
            this.bunifuButton2.ColorContrastOnClick = 45;
            this.bunifuButton2.ColorContrastOnHover = 45;
            this.bunifuButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges6.BottomLeft = true;
            borderEdges6.BottomRight = true;
            borderEdges6.TopLeft = true;
            borderEdges6.TopRight = true;
            this.bunifuButton2.CustomizableEdges = borderEdges6;
            this.bunifuButton2.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton2.DisabledBorderColor = System.Drawing.Color.Empty;
            this.bunifuButton2.DisabledFillColor = System.Drawing.Color.Transparent;
            this.bunifuButton2.DisabledForecolor = System.Drawing.Color.Transparent;
            this.bunifuButton2.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.bunifuButton2.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.bunifuButton2.ForeColor = System.Drawing.Color.White;
            this.bunifuButton2.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuButton2.IconMarginLeft = 11;
            this.bunifuButton2.IconPadding = 10;
            this.bunifuButton2.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuButton2.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.bunifuButton2.IdleBorderRadius = 30;
            this.bunifuButton2.IdleBorderThickness = 1;
            this.bunifuButton2.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.bunifuButton2.IdleIconLeftImage = null;
            this.bunifuButton2.IdleIconRightImage = null;
            this.bunifuButton2.IndicateFocus = false;
            this.bunifuButton2.Location = new System.Drawing.Point(57, 319);
            this.bunifuButton2.Name = "bunifuButton2";
            this.bunifuButton2.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.bunifuButton2.onHoverState.BorderRadius = 30;
            this.bunifuButton2.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton2.onHoverState.BorderThickness = 1;
            this.bunifuButton2.onHoverState.FillColor = System.Drawing.Color.White;
            this.bunifuButton2.onHoverState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.bunifuButton2.onHoverState.IconLeftImage = null;
            this.bunifuButton2.onHoverState.IconRightImage = null;
            this.bunifuButton2.OnIdleState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.bunifuButton2.OnIdleState.BorderRadius = 30;
            this.bunifuButton2.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton2.OnIdleState.BorderThickness = 1;
            this.bunifuButton2.OnIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.bunifuButton2.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton2.OnIdleState.IconLeftImage = null;
            this.bunifuButton2.OnIdleState.IconRightImage = null;
            this.bunifuButton2.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.bunifuButton2.OnPressedState.BorderRadius = 30;
            this.bunifuButton2.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton2.OnPressedState.BorderThickness = 1;
            this.bunifuButton2.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.bunifuButton2.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton2.OnPressedState.IconLeftImage = null;
            this.bunifuButton2.OnPressedState.IconRightImage = null;
            this.bunifuButton2.Size = new System.Drawing.Size(110, 37);
            this.bunifuButton2.TabIndex = 3;
            this.bunifuButton2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton2.TextMarginLeft = 0;
            this.bunifuButton2.UseDefaultRadiusAndThickness = true;
            this.bunifuButton2.Click += new System.EventHandler(this.bunifuButton2_Click);
            // 
            // bunifuButton1
            // 
            this.bunifuButton1.AllowToggling = false;
            this.bunifuButton1.AnimationSpeed = 200;
            this.bunifuButton1.AutoGenerateColors = false;
            this.bunifuButton1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton1.BackColor1 = System.Drawing.Color.White;
            this.bunifuButton1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton1.BackgroundImage")));
            this.bunifuButton1.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton1.ButtonText = "ADMIN";
            this.bunifuButton1.ButtonTextMarginLeft = 0;
            this.bunifuButton1.ColorContrastOnClick = 45;
            this.bunifuButton1.ColorContrastOnHover = 45;
            this.bunifuButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges5.BottomLeft = true;
            borderEdges5.BottomRight = true;
            borderEdges5.TopLeft = true;
            borderEdges5.TopRight = true;
            this.bunifuButton1.CustomizableEdges = borderEdges5;
            this.bunifuButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton1.DisabledBorderColor = System.Drawing.Color.Empty;
            this.bunifuButton1.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton1.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton1.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.bunifuButton1.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.bunifuButton1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.bunifuButton1.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuButton1.IconMarginLeft = 11;
            this.bunifuButton1.IconPadding = 10;
            this.bunifuButton1.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuButton1.IdleBorderColor = System.Drawing.Color.White;
            this.bunifuButton1.IdleBorderRadius = 34;
            this.bunifuButton1.IdleBorderThickness = 1;
            this.bunifuButton1.IdleFillColor = System.Drawing.Color.White;
            this.bunifuButton1.IdleIconLeftImage = null;
            this.bunifuButton1.IdleIconRightImage = null;
            this.bunifuButton1.IndicateFocus = false;
            this.bunifuButton1.Location = new System.Drawing.Point(198, 319);
            this.bunifuButton1.Name = "bunifuButton1";
            this.bunifuButton1.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.bunifuButton1.onHoverState.BorderRadius = 34;
            this.bunifuButton1.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton1.onHoverState.BorderThickness = 1;
            this.bunifuButton1.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.bunifuButton1.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton1.onHoverState.IconLeftImage = null;
            this.bunifuButton1.onHoverState.IconRightImage = null;
            this.bunifuButton1.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.bunifuButton1.OnIdleState.BorderRadius = 34;
            this.bunifuButton1.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton1.OnIdleState.BorderThickness = 1;
            this.bunifuButton1.OnIdleState.FillColor = System.Drawing.Color.White;
            this.bunifuButton1.OnIdleState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.bunifuButton1.OnIdleState.IconLeftImage = null;
            this.bunifuButton1.OnIdleState.IconRightImage = null;
            this.bunifuButton1.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.bunifuButton1.OnPressedState.BorderRadius = 34;
            this.bunifuButton1.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton1.OnPressedState.BorderThickness = 1;
            this.bunifuButton1.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.bunifuButton1.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton1.OnPressedState.IconLeftImage = null;
            this.bunifuButton1.OnPressedState.IconRightImage = null;
            this.bunifuButton1.Size = new System.Drawing.Size(110, 37);
            this.bunifuButton1.TabIndex = 3;
            this.bunifuButton1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton1.TextMarginLeft = 0;
            this.bunifuButton1.UseDefaultRadiusAndThickness = true;
            this.bunifuButton1.Click += new System.EventHandler(this.bunifuButton1_Click);
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.Controls.Add(this.bunifuButton1);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuButton2);
            this.bunifuGradientPanel1.Controls.Add(this.pictureBox1);
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(6)))), ((int)(((byte)(106)))));
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(6)))), ((int)(((byte)(88)))));
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(6)))), ((int)(((byte)(106)))));
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(-1, 0);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(367, 396);
            this.bunifuGradientPanel1.TabIndex = 2;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::Vender.Properties.Resources.loginBack;
            this.pictureBox1.Location = new System.Drawing.Point(30, 23);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(304, 303);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(777, 396);
            this.Controls.Add(this.bunifuGradientPanel1);
            this.Controls.Add(this.bunifuPages1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Login";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Login";
            this.bunifuPages1.ResumeLayout(false);
            this.SellersPage.ResumeLayout(false);
            this.SellersPage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).EndInit();
            this.AdminPage.ResumeLayout(false);
            this.AdminPage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton2)).EndInit();
            this.bunifuGradientPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.UI.WinForms.BunifuFormDock bunifuFormDock1;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton1;
        private Bunifu.UI.WinForms.BunifuPages bunifuPages1;
        private System.Windows.Forms.TabPage SellersPage;
        private System.Windows.Forms.TabPage AdminPage;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton2;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton1;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel2;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator1;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox TexteBoxPaswordSellerLogin;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox TextBoxUsernameSellerLogin;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox TextBoxadminUPassword;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton AdminLoginButton;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox TextBoxadminUsername;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel3;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator2;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton2;
        private Bunifu.Framework.UI.BunifuThinButton2 clearBtn;
        private Bunifu.Framework.UI.BunifuThinButton2 ClearButtonSeller;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton ButtonLoginSeller;
        private Bunifu.Framework.UI.BunifuCustomLabel LabelErrorAdmin;
        private Bunifu.Framework.UI.BunifuCustomLabel LabelSellerMessage;
        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

