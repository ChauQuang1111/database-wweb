﻿namespace Vender.Forms
{
    partial class SignUp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SignUp));
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties13 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties14 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties15 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties16 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties17 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties18 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties19 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties20 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges2 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties21 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties22 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties23 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties24 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            this.TextBoxUsername = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.bunifuLabel3 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuSeparator2 = new Bunifu.Framework.UI.BunifuSeparator();
            this.clearBtn = new Bunifu.Framework.UI.BunifuThinButton2();
            this.TextBoxtRepeatPassword = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.ButtonSignUp = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.TextBoxPassword = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.bunifuGradientPanel1 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.LabelMessage = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuImageButton1 = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuFormDock1 = new Bunifu.UI.WinForms.BunifuFormDock();
            this.bunifuGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).BeginInit();
            this.SuspendLayout();
            // 
            // TextBoxUsername
            // 
            this.TextBoxUsername.AcceptsReturn = false;
            this.TextBoxUsername.AcceptsTab = false;
            this.TextBoxUsername.AnimationSpeed = 200;
            this.TextBoxUsername.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.TextBoxUsername.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.TextBoxUsername.BackColor = System.Drawing.Color.Transparent;
            this.TextBoxUsername.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("TextBoxUsername.BackgroundImage")));
            this.TextBoxUsername.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.TextBoxUsername.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.TextBoxUsername.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.TextBoxUsername.BorderColorIdle = System.Drawing.Color.Silver;
            this.TextBoxUsername.BorderRadius = 1;
            this.TextBoxUsername.BorderThickness = 1;
            this.TextBoxUsername.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.TextBoxUsername.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxUsername.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.TextBoxUsername.DefaultText = "";
            this.TextBoxUsername.FillColor = System.Drawing.Color.White;
            this.TextBoxUsername.HideSelection = true;
            this.TextBoxUsername.IconLeft = global::Vender.Properties.Resources.user_512px;
            this.TextBoxUsername.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxUsername.IconPadding = 10;
            this.TextBoxUsername.IconRight = null;
            this.TextBoxUsername.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxUsername.Lines = new string[0];
            this.TextBoxUsername.Location = new System.Drawing.Point(448, 107);
            this.TextBoxUsername.MaxLength = 32767;
            this.TextBoxUsername.MinimumSize = new System.Drawing.Size(1, 1);
            this.TextBoxUsername.Modified = false;
            this.TextBoxUsername.Multiline = false;
            this.TextBoxUsername.Name = "TextBoxUsername";
            stateProperties13.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            stateProperties13.FillColor = System.Drawing.Color.Empty;
            stateProperties13.ForeColor = System.Drawing.Color.Empty;
            stateProperties13.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.TextBoxUsername.OnActiveState = stateProperties13;
            stateProperties14.BorderColor = System.Drawing.Color.Empty;
            stateProperties14.FillColor = System.Drawing.Color.White;
            stateProperties14.ForeColor = System.Drawing.Color.Empty;
            stateProperties14.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.TextBoxUsername.OnDisabledState = stateProperties14;
            stateProperties15.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            stateProperties15.FillColor = System.Drawing.Color.Empty;
            stateProperties15.ForeColor = System.Drawing.Color.Empty;
            stateProperties15.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.TextBoxUsername.OnHoverState = stateProperties15;
            stateProperties16.BorderColor = System.Drawing.Color.Silver;
            stateProperties16.FillColor = System.Drawing.Color.White;
            stateProperties16.ForeColor = System.Drawing.Color.Empty;
            stateProperties16.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.TextBoxUsername.OnIdleState = stateProperties16;
            this.TextBoxUsername.PasswordChar = '\0';
            this.TextBoxUsername.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.TextBoxUsername.PlaceholderText = "Username";
            this.TextBoxUsername.ReadOnly = false;
            this.TextBoxUsername.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.TextBoxUsername.SelectedText = "";
            this.TextBoxUsername.SelectionLength = 0;
            this.TextBoxUsername.SelectionStart = 0;
            this.TextBoxUsername.ShortcutsEnabled = true;
            this.TextBoxUsername.Size = new System.Drawing.Size(307, 35);
            this.TextBoxUsername.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.TextBoxUsername.TabIndex = 19;
            this.TextBoxUsername.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.TextBoxUsername.TextMarginBottom = 0;
            this.TextBoxUsername.TextMarginLeft = 5;
            this.TextBoxUsername.TextMarginTop = 0;
            this.TextBoxUsername.TextPlaceholder = "Username";
            this.TextBoxUsername.UseSystemPasswordChar = false;
            this.TextBoxUsername.WordWrap = true;
            this.TextBoxUsername.Click += new System.EventHandler(this.TextBoxUsername_Click);
            // 
            // bunifuLabel3
            // 
            this.bunifuLabel3.AutoEllipsis = false;
            this.bunifuLabel3.CursorType = null;
            this.bunifuLabel3.Font = new System.Drawing.Font("Segoe UI Black", 14.25F, System.Drawing.FontStyle.Bold);
            this.bunifuLabel3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.bunifuLabel3.Location = new System.Drawing.Point(561, 28);
            this.bunifuLabel3.Name = "bunifuLabel3";
            this.bunifuLabel3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel3.Size = new System.Drawing.Size(70, 27);
            this.bunifuLabel3.TabIndex = 16;
            this.bunifuLabel3.Text = "SignUp";
            this.bunifuLabel3.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel3.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuSeparator2
            // 
            this.bunifuSeparator2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator2.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.bunifuSeparator2.LineThickness = 1;
            this.bunifuSeparator2.Location = new System.Drawing.Point(548, 53);
            this.bunifuSeparator2.Name = "bunifuSeparator2";
            this.bunifuSeparator2.Size = new System.Drawing.Size(97, 35);
            this.bunifuSeparator2.TabIndex = 17;
            this.bunifuSeparator2.Transparency = 255;
            this.bunifuSeparator2.Vertical = false;
            // 
            // clearBtn
            // 
            this.clearBtn.ActiveBorderThickness = 1;
            this.clearBtn.ActiveCornerRadius = 20;
            this.clearBtn.ActiveFillColor = System.Drawing.Color.White;
            this.clearBtn.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.clearBtn.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.clearBtn.BackColor = System.Drawing.Color.White;
            this.clearBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("clearBtn.BackgroundImage")));
            this.clearBtn.ButtonText = "Clear";
            this.clearBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.clearBtn.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.clearBtn.IdleBorderThickness = 1;
            this.clearBtn.IdleCornerRadius = 30;
            this.clearBtn.IdleFillColor = System.Drawing.Color.White;
            this.clearBtn.IdleForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.clearBtn.IdleLineColor = System.Drawing.Color.White;
            this.clearBtn.Location = new System.Drawing.Point(523, 270);
            this.clearBtn.Margin = new System.Windows.Forms.Padding(5);
            this.clearBtn.Name = "clearBtn";
            this.clearBtn.Size = new System.Drawing.Size(103, 44);
            this.clearBtn.TabIndex = 21;
            this.clearBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.clearBtn.Click += new System.EventHandler(this.clearBtn_Click);
            // 
            // TextBoxtRepeatPassword
            // 
            this.TextBoxtRepeatPassword.AcceptsReturn = false;
            this.TextBoxtRepeatPassword.AcceptsTab = false;
            this.TextBoxtRepeatPassword.AnimationSpeed = 200;
            this.TextBoxtRepeatPassword.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.TextBoxtRepeatPassword.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.TextBoxtRepeatPassword.BackColor = System.Drawing.Color.Transparent;
            this.TextBoxtRepeatPassword.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("TextBoxtRepeatPassword.BackgroundImage")));
            this.TextBoxtRepeatPassword.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.TextBoxtRepeatPassword.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.TextBoxtRepeatPassword.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.TextBoxtRepeatPassword.BorderColorIdle = System.Drawing.Color.Silver;
            this.TextBoxtRepeatPassword.BorderRadius = 1;
            this.TextBoxtRepeatPassword.BorderThickness = 1;
            this.TextBoxtRepeatPassword.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.TextBoxtRepeatPassword.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxtRepeatPassword.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.TextBoxtRepeatPassword.DefaultText = "";
            this.TextBoxtRepeatPassword.FillColor = System.Drawing.Color.White;
            this.TextBoxtRepeatPassword.HideSelection = true;
            this.TextBoxtRepeatPassword.IconLeft = global::Vender.Properties.Resources.password_144px;
            this.TextBoxtRepeatPassword.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxtRepeatPassword.IconPadding = 10;
            this.TextBoxtRepeatPassword.IconRight = null;
            this.TextBoxtRepeatPassword.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxtRepeatPassword.Lines = new string[0];
            this.TextBoxtRepeatPassword.Location = new System.Drawing.Point(448, 218);
            this.TextBoxtRepeatPassword.MaxLength = 32767;
            this.TextBoxtRepeatPassword.MinimumSize = new System.Drawing.Size(1, 1);
            this.TextBoxtRepeatPassword.Modified = false;
            this.TextBoxtRepeatPassword.Multiline = false;
            this.TextBoxtRepeatPassword.Name = "TextBoxtRepeatPassword";
            stateProperties17.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            stateProperties17.FillColor = System.Drawing.Color.Empty;
            stateProperties17.ForeColor = System.Drawing.Color.Empty;
            stateProperties17.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.TextBoxtRepeatPassword.OnActiveState = stateProperties17;
            stateProperties18.BorderColor = System.Drawing.Color.Empty;
            stateProperties18.FillColor = System.Drawing.Color.White;
            stateProperties18.ForeColor = System.Drawing.Color.Empty;
            stateProperties18.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.TextBoxtRepeatPassword.OnDisabledState = stateProperties18;
            stateProperties19.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            stateProperties19.FillColor = System.Drawing.Color.Empty;
            stateProperties19.ForeColor = System.Drawing.Color.Empty;
            stateProperties19.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.TextBoxtRepeatPassword.OnHoverState = stateProperties19;
            stateProperties20.BorderColor = System.Drawing.Color.Silver;
            stateProperties20.FillColor = System.Drawing.Color.White;
            stateProperties20.ForeColor = System.Drawing.Color.Empty;
            stateProperties20.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.TextBoxtRepeatPassword.OnIdleState = stateProperties20;
            this.TextBoxtRepeatPassword.PasswordChar = '*';
            this.TextBoxtRepeatPassword.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.TextBoxtRepeatPassword.PlaceholderText = "Password";
            this.TextBoxtRepeatPassword.ReadOnly = false;
            this.TextBoxtRepeatPassword.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.TextBoxtRepeatPassword.SelectedText = "";
            this.TextBoxtRepeatPassword.SelectionLength = 0;
            this.TextBoxtRepeatPassword.SelectionStart = 0;
            this.TextBoxtRepeatPassword.ShortcutsEnabled = true;
            this.TextBoxtRepeatPassword.Size = new System.Drawing.Size(307, 35);
            this.TextBoxtRepeatPassword.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.TextBoxtRepeatPassword.TabIndex = 18;
            this.TextBoxtRepeatPassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.TextBoxtRepeatPassword.TextMarginBottom = 0;
            this.TextBoxtRepeatPassword.TextMarginLeft = 5;
            this.TextBoxtRepeatPassword.TextMarginTop = 0;
            this.TextBoxtRepeatPassword.TextPlaceholder = "Password";
            this.TextBoxtRepeatPassword.UseSystemPasswordChar = false;
            this.TextBoxtRepeatPassword.WordWrap = true;
            this.TextBoxtRepeatPassword.Click += new System.EventHandler(this.TextBoxtRepeatPassword_Click);
            // 
            // ButtonSignUp
            // 
            this.ButtonSignUp.AllowToggling = false;
            this.ButtonSignUp.AnimationSpeed = 200;
            this.ButtonSignUp.AutoGenerateColors = false;
            this.ButtonSignUp.BackColor = System.Drawing.Color.Transparent;
            this.ButtonSignUp.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.ButtonSignUp.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ButtonSignUp.BackgroundImage")));
            this.ButtonSignUp.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ButtonSignUp.ButtonText = "sign up";
            this.ButtonSignUp.ButtonTextMarginLeft = 0;
            this.ButtonSignUp.ColorContrastOnClick = 45;
            this.ButtonSignUp.ColorContrastOnHover = 45;
            this.ButtonSignUp.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges2.BottomLeft = true;
            borderEdges2.BottomRight = true;
            borderEdges2.TopLeft = true;
            borderEdges2.TopRight = true;
            this.ButtonSignUp.CustomizableEdges = borderEdges2;
            this.ButtonSignUp.DialogResult = System.Windows.Forms.DialogResult.None;
            this.ButtonSignUp.DisabledBorderColor = System.Drawing.Color.Empty;
            this.ButtonSignUp.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.ButtonSignUp.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.ButtonSignUp.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.ButtonSignUp.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.ButtonSignUp.ForeColor = System.Drawing.Color.White;
            this.ButtonSignUp.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.ButtonSignUp.IconMarginLeft = 11;
            this.ButtonSignUp.IconPadding = 10;
            this.ButtonSignUp.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.ButtonSignUp.IdleBorderColor = System.Drawing.Color.White;
            this.ButtonSignUp.IdleBorderRadius = 30;
            this.ButtonSignUp.IdleBorderThickness = 1;
            this.ButtonSignUp.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.ButtonSignUp.IdleIconLeftImage = null;
            this.ButtonSignUp.IdleIconRightImage = null;
            this.ButtonSignUp.IndicateFocus = false;
            this.ButtonSignUp.Location = new System.Drawing.Point(645, 274);
            this.ButtonSignUp.Name = "ButtonSignUp";
            this.ButtonSignUp.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.ButtonSignUp.onHoverState.BorderRadius = 30;
            this.ButtonSignUp.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ButtonSignUp.onHoverState.BorderThickness = 1;
            this.ButtonSignUp.onHoverState.FillColor = System.Drawing.Color.White;
            this.ButtonSignUp.onHoverState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.ButtonSignUp.onHoverState.IconLeftImage = null;
            this.ButtonSignUp.onHoverState.IconRightImage = null;
            this.ButtonSignUp.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.ButtonSignUp.OnIdleState.BorderRadius = 30;
            this.ButtonSignUp.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ButtonSignUp.OnIdleState.BorderThickness = 1;
            this.ButtonSignUp.OnIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.ButtonSignUp.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.ButtonSignUp.OnIdleState.IconLeftImage = null;
            this.ButtonSignUp.OnIdleState.IconRightImage = null;
            this.ButtonSignUp.OnPressedState.BorderColor = System.Drawing.Color.White;
            this.ButtonSignUp.OnPressedState.BorderRadius = 30;
            this.ButtonSignUp.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ButtonSignUp.OnPressedState.BorderThickness = 1;
            this.ButtonSignUp.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.ButtonSignUp.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.ButtonSignUp.OnPressedState.IconLeftImage = null;
            this.ButtonSignUp.OnPressedState.IconRightImage = null;
            this.ButtonSignUp.Size = new System.Drawing.Size(110, 37);
            this.ButtonSignUp.TabIndex = 15;
            this.ButtonSignUp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ButtonSignUp.TextMarginLeft = 0;
            this.ButtonSignUp.UseDefaultRadiusAndThickness = true;
            this.ButtonSignUp.Click += new System.EventHandler(this.ButtonSignUp_Click);
            // 
            // TextBoxPassword
            // 
            this.TextBoxPassword.AcceptsReturn = false;
            this.TextBoxPassword.AcceptsTab = false;
            this.TextBoxPassword.AnimationSpeed = 200;
            this.TextBoxPassword.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.TextBoxPassword.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.TextBoxPassword.BackColor = System.Drawing.Color.Transparent;
            this.TextBoxPassword.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("TextBoxPassword.BackgroundImage")));
            this.TextBoxPassword.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.TextBoxPassword.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.TextBoxPassword.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.TextBoxPassword.BorderColorIdle = System.Drawing.Color.Silver;
            this.TextBoxPassword.BorderRadius = 1;
            this.TextBoxPassword.BorderThickness = 1;
            this.TextBoxPassword.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.TextBoxPassword.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxPassword.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.TextBoxPassword.DefaultText = "";
            this.TextBoxPassword.FillColor = System.Drawing.Color.White;
            this.TextBoxPassword.HideSelection = true;
            this.TextBoxPassword.IconLeft = global::Vender.Properties.Resources.password_144px;
            this.TextBoxPassword.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxPassword.IconPadding = 10;
            this.TextBoxPassword.IconRight = null;
            this.TextBoxPassword.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxPassword.Lines = new string[0];
            this.TextBoxPassword.Location = new System.Drawing.Point(448, 161);
            this.TextBoxPassword.MaxLength = 32767;
            this.TextBoxPassword.MinimumSize = new System.Drawing.Size(1, 1);
            this.TextBoxPassword.Modified = false;
            this.TextBoxPassword.Multiline = false;
            this.TextBoxPassword.Name = "TextBoxPassword";
            stateProperties21.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            stateProperties21.FillColor = System.Drawing.Color.Empty;
            stateProperties21.ForeColor = System.Drawing.Color.Empty;
            stateProperties21.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.TextBoxPassword.OnActiveState = stateProperties21;
            stateProperties22.BorderColor = System.Drawing.Color.Empty;
            stateProperties22.FillColor = System.Drawing.Color.White;
            stateProperties22.ForeColor = System.Drawing.Color.Empty;
            stateProperties22.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.TextBoxPassword.OnDisabledState = stateProperties22;
            stateProperties23.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            stateProperties23.FillColor = System.Drawing.Color.Empty;
            stateProperties23.ForeColor = System.Drawing.Color.Empty;
            stateProperties23.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.TextBoxPassword.OnHoverState = stateProperties23;
            stateProperties24.BorderColor = System.Drawing.Color.Silver;
            stateProperties24.FillColor = System.Drawing.Color.White;
            stateProperties24.ForeColor = System.Drawing.Color.Empty;
            stateProperties24.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.TextBoxPassword.OnIdleState = stateProperties24;
            this.TextBoxPassword.PasswordChar = '*';
            this.TextBoxPassword.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.TextBoxPassword.PlaceholderText = "Password";
            this.TextBoxPassword.ReadOnly = false;
            this.TextBoxPassword.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.TextBoxPassword.SelectedText = "";
            this.TextBoxPassword.SelectionLength = 0;
            this.TextBoxPassword.SelectionStart = 0;
            this.TextBoxPassword.ShortcutsEnabled = true;
            this.TextBoxPassword.Size = new System.Drawing.Size(307, 35);
            this.TextBoxPassword.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.TextBoxPassword.TabIndex = 18;
            this.TextBoxPassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.TextBoxPassword.TextMarginBottom = 0;
            this.TextBoxPassword.TextMarginLeft = 5;
            this.TextBoxPassword.TextMarginTop = 0;
            this.TextBoxPassword.TextPlaceholder = "Password";
            this.TextBoxPassword.UseSystemPasswordChar = false;
            this.TextBoxPassword.WordWrap = true;
            this.TextBoxPassword.Click += new System.EventHandler(this.TextBoxPassword_Click);
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.Controls.Add(this.pictureBox1);
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(6)))), ((int)(((byte)(106)))));
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(6)))), ((int)(((byte)(88)))));
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(6)))), ((int)(((byte)(106)))));
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(28)))), ((int)(((byte)(193)))));
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(0, -1);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(385, 395);
            this.bunifuGradientPanel1.TabIndex = 22;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::Vender.Properties.Resources.loginBack;
            this.pictureBox1.Location = new System.Drawing.Point(25, 29);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(325, 315);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 23;
            this.pictureBox1.TabStop = false;
            // 
            // LabelMessage
            // 
            this.LabelMessage.AutoSize = true;
            this.LabelMessage.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelMessage.ForeColor = System.Drawing.Color.Red;
            this.LabelMessage.Location = new System.Drawing.Point(444, 336);
            this.LabelMessage.Name = "LabelMessage";
            this.LabelMessage.Size = new System.Drawing.Size(0, 21);
            this.LabelMessage.TabIndex = 23;
            // 
            // bunifuImageButton1
            // 
            this.bunifuImageButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuImageButton1.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton1.Image")));
            this.bunifuImageButton1.ImageActive = null;
            this.bunifuImageButton1.Location = new System.Drawing.Point(755, 12);
            this.bunifuImageButton1.Name = "bunifuImageButton1";
            this.bunifuImageButton1.Size = new System.Drawing.Size(32, 21);
            this.bunifuImageButton1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton1.TabIndex = 24;
            this.bunifuImageButton1.TabStop = false;
            this.bunifuImageButton1.Zoom = 10;
            this.bunifuImageButton1.Click += new System.EventHandler(this.bunifuImageButton1_Click);
            // 
            // bunifuFormDock1
            // 
            this.bunifuFormDock1.AllowFormDragging = true;
            this.bunifuFormDock1.AllowFormDropShadow = true;
            this.bunifuFormDock1.AllowFormResizing = false;
            this.bunifuFormDock1.AllowHidingBottomRegion = true;
            this.bunifuFormDock1.AllowOpacityChangesWhileDragging = true;
            this.bunifuFormDock1.BorderOptions.BottomBorder.BorderColor = System.Drawing.Color.Silver;
            this.bunifuFormDock1.BorderOptions.BottomBorder.BorderThickness = 1;
            this.bunifuFormDock1.BorderOptions.BottomBorder.ShowBorder = true;
            this.bunifuFormDock1.BorderOptions.LeftBorder.BorderColor = System.Drawing.Color.Silver;
            this.bunifuFormDock1.BorderOptions.LeftBorder.BorderThickness = 1;
            this.bunifuFormDock1.BorderOptions.LeftBorder.ShowBorder = true;
            this.bunifuFormDock1.BorderOptions.RightBorder.BorderColor = System.Drawing.Color.Silver;
            this.bunifuFormDock1.BorderOptions.RightBorder.BorderThickness = 1;
            this.bunifuFormDock1.BorderOptions.RightBorder.ShowBorder = true;
            this.bunifuFormDock1.BorderOptions.TopBorder.BorderColor = System.Drawing.Color.Silver;
            this.bunifuFormDock1.BorderOptions.TopBorder.BorderThickness = 1;
            this.bunifuFormDock1.BorderOptions.TopBorder.ShowBorder = true;
            this.bunifuFormDock1.ContainerControl = this;
            this.bunifuFormDock1.DockingIndicatorsColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(215)))), ((int)(((byte)(233)))));
            this.bunifuFormDock1.DockingIndicatorsOpacity = 0.5D;
            this.bunifuFormDock1.DockingOptions.DockAll = true;
            this.bunifuFormDock1.DockingOptions.DockBottomLeft = true;
            this.bunifuFormDock1.DockingOptions.DockBottomRight = true;
            this.bunifuFormDock1.DockingOptions.DockFullScreen = true;
            this.bunifuFormDock1.DockingOptions.DockLeft = true;
            this.bunifuFormDock1.DockingOptions.DockRight = true;
            this.bunifuFormDock1.DockingOptions.DockTopLeft = true;
            this.bunifuFormDock1.DockingOptions.DockTopRight = true;
            this.bunifuFormDock1.FormDraggingOpacity = 0.9D;
            this.bunifuFormDock1.ParentForm = this;
            this.bunifuFormDock1.ShowCursorChanges = true;
            this.bunifuFormDock1.ShowDockingIndicators = false;
            this.bunifuFormDock1.TitleBarOptions.AllowFormDragging = true;
            this.bunifuFormDock1.TitleBarOptions.BunifuFormDock = this.bunifuFormDock1;
            this.bunifuFormDock1.TitleBarOptions.DoubleClickToExpandWindow = true;
            this.bunifuFormDock1.TitleBarOptions.TitleBarControl = null;
            this.bunifuFormDock1.TitleBarOptions.UseBackColorOnDockingIndicators = false;
            // 
            // SignUp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(799, 394);
            this.Controls.Add(this.bunifuImageButton1);
            this.Controls.Add(this.LabelMessage);
            this.Controls.Add(this.bunifuGradientPanel1);
            this.Controls.Add(this.TextBoxUsername);
            this.Controls.Add(this.bunifuLabel3);
            this.Controls.Add(this.bunifuSeparator2);
            this.Controls.Add(this.clearBtn);
            this.Controls.Add(this.TextBoxPassword);
            this.Controls.Add(this.TextBoxtRepeatPassword);
            this.Controls.Add(this.ButtonSignUp);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SignUp";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SignUp";
            this.bunifuGradientPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox TextBoxUsername;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel3;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator2;
        private Bunifu.Framework.UI.BunifuThinButton2 clearBtn;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox TextBoxtRepeatPassword;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton ButtonSignUp;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox TextBoxPassword;
        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Bunifu.Framework.UI.BunifuCustomLabel LabelMessage;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton1;
        private Bunifu.UI.WinForms.BunifuFormDock bunifuFormDock1;
    }
}