﻿SELECT Quantity FROM Product WHERE Name='Apple';

UPDATE Product SET Quantity = Quantity-1 WHERE Name ='Apple';