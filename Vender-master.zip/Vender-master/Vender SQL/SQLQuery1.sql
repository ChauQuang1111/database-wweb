﻿SELECT  SUM(Total) AS Total FROM Bill Where;

SELECT COUNT(Name) AS total from Category;


SELECT  SUM(Quantity) AS Total FROM Product;


SELECT Quantity FROM Product Where Name="Apple";