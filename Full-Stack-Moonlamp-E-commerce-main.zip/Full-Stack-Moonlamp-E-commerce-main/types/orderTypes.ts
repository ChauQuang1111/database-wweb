export type OrderTypes ={
  id: string;
  amount: number;
  createdDate: string;
  status: string;
}