-- AlterTable
ALTER TABLE "Product" ALTER COLUMN "unit_amount" DROP NOT NULL;
