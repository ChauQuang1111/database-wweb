-- AlterTable
ALTER TABLE "OrderProduct" ALTER COLUMN "quantity" DROP NOT NULL;
