export { default as HomeScreen } from "./HomeScreen";
export { default as OnBoardingScreen } from "./OnBoardingScreen";
export { default as ProductScreen } from "./ProductScreen";
export { default as CartScreen } from "./CartScreen";
