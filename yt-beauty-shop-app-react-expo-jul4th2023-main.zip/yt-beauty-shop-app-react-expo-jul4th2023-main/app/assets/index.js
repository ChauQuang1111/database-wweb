export { default as Brand } from "./brand.png";
export { default as Screen1 } from "./screen1.png";
export { default as Screen2 } from "./screen2.jpg";
export { default as Screen3 } from "./screen3.jpeg";
export { default as EmptyCart } from "./emptycart.png";
