export { default as Feeds } from "./Feeds";
export { default as FeedDetail } from "./FeedDetail";
export { default as BottomTab } from "./BottomTab";
