import category from './category'
import products from './products'

export const schemaTypes = [products, category]
